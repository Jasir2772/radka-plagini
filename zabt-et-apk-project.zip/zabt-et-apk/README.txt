APK olish (telefondan ham bo'ladi):
1) github.com da bepul akkaunt oching, yangi repository yarating.
2) Shu papkadagi hamma fayllarni (.github papkasi bilan) repository ga yuklang.
3) Repository > Actions > "Build APK" ishga tushishini kuting (5-10 daqiqa).
4) Tugagach, run sahifasidagi Artifacts > zabt-et-apk ni yuklab oling, zip ichida app-debug.apk bor.
5) APK ni telefonga o'rnating ("noma'lum manbalardan o'rnatish" ruxsati kerak).

Kompyuterda o'zingiz qurish: Node 20, JDK 17, Android SDK kerak.
npm install && npx cap add android && npx cap sync android && cd android && ./gradlew assembleDebug
