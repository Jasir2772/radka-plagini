(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const esc = (t) => String(t).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const norm = (t) => String(t).toLowerCase().replace(/[\u2018\u2019\u02bb\u02bc`´']/g, "'");

  /* ---------------- persistent state ---------------- */
  const KEY = 's6.v1';
  const state = { seen: {}, done: {}, last: 0, sound: true };
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) Object.assign(state, JSON.parse(raw));
  } catch (e) { /* storage unavailable: run without persistence */ }
  const save = () => { try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* ignore */ } };

  /* ---------------- sound effects (WebAudio, no files) ---------------- */
  const Sfx = (() => {
    let ctx = null;
    const getCtx = () => {
      if (!ctx) {
        const AC = window.AudioContext || window.webkitAudioContext;
        if (!AC) return null;
        try { ctx = new AC(); } catch (e) { return null; }
      }
      return ctx;
    };
    const run = (fn) => {
      if (!state.sound) return;
      const c = getCtx();
      if (!c) return;
      if (c.state === 'running') fn(c);
      else c.resume().then(() => { if (c.state === 'running') fn(c); }).catch(() => {});
    };
    const runNow = (fn) => {   // only if audio is already allowed to run; never queues a resume
      if (!state.sound) return;
      const c = getCtx();
      if (c && c.state === 'running') fn(c);
    };
    const tone = (c, f, t, d, type, v, to) => {
      const o = c.createOscillator(), g = c.createGain(), t0 = c.currentTime + t;
      o.type = type;
      o.frequency.setValueAtTime(f, t0);
      if (to) o.frequency.exponentialRampToValueAtTime(to, t0 + d);
      g.gain.setValueAtTime(0.0001, t0);
      g.gain.exponentialRampToValueAtTime(v, t0 + 0.012);
      g.gain.exponentialRampToValueAtTime(0.0001, t0 + d);
      o.connect(g); g.connect(c.destination);
      o.start(t0); o.stop(t0 + d + 0.03);
    };
    return {
      unlock() { const c = getCtx(); if (c && c.state === 'suspended') c.resume().catch(() => {}); },
      tap()   { run((c) => tone(c, 620, 0, 0.07, 'sine', 0.11)); },
      tick()  { run((c) => tone(c, 900, 0, 0.05, 'triangle', 0.08)); },
      open()  { run((c) => { tone(c, 523, 0, 0.1, 'sine', 0.12); tone(c, 784, 0.07, 0.16, 'sine', 0.12); }); },
      back()  { run((c) => { tone(c, 784, 0, 0.09, 'sine', 0.11); tone(c, 523, 0.07, 0.14, 'sine', 0.11); }); },
      chime() { runNow((c) => [523, 659, 784, 1047].forEach((f, i) => tone(c, f, i * 0.11, 0.38, 'sine', 0.1))); },
      win()   { run((c) => [659, 784, 988, 1319].forEach((f, i) => tone(c, f, i * 0.09, 0.3, 'triangle', 0.12))); },
    };
  })();
  ['pointerdown', 'touchstart', 'keydown'].forEach((ev) => window.addEventListener(ev, () => Sfx.unlock(), { capture: true, passive: true }));

  /* ---------------- data ---------------- */
  let groups = [], lessons = [], byN = {}, groupOf = {}, order = [];
  let cur = 0;              // currently open lesson number (0 = home)
  let filterGroup = 'all';
  let query = '';
  let vTimer = 0;

  const els = {
    home: $('#home'), lesson: $('#lesson'), list: $('#list'), chips: $('#chips'), q: $('#q'), qClear: $('#qClear'),
    cont: $('#cont'), contTitle: $('#contTitle'), heroSub: $('#heroSub'), ringFg: $('#ringFg'), ringPct: $('#ringPct'),
    progTxt: $('#progTxt'), sound: $('#soundBtn'), lTitle: $('#lTitle'), lGroup: $('#lGroup'), prev: $('#prevBtn'),
    next: $('#nextBtn'), back: $('#backBtn'), tabs: $('#tabs'), frame: $('#frame'), vpanel: $('#vpanel'), spin: $('#spin'),
    toast: $('#toast'), splash: $('#splash'), homeScroll: $('#homeScroll'),
  };

  /* ---------------- helpers ---------------- */
  let toastTimer = 0;
  function toast(msg) {
    els.toast.textContent = msg;
    els.toast.classList.add('on');
    clearTimeout(toastTimer);
    toastTimer = setTimeout(() => els.toast.classList.remove('on'), 3000);
  }

  function ripple(e) {
    const t = e.target.closest('.card, .icon-btn, .chip, .cont');
    if (!t) return;
    const r = t.getBoundingClientRect();
    const size = Math.max(r.width, r.height) * 1.6;
    const s = document.createElement('span');
    s.className = 'rp';
    s.style.cssText = `width:${size}px;height:${size}px;left:${e.clientX - r.left - size / 2}px;top:${e.clientY - r.top - size / 2}px`;
    t.appendChild(s);
    setTimeout(() => s.remove(), 650);
  }
  document.addEventListener('pointerdown', ripple, { passive: true });

  /* ---------------- progress ---------------- */
  function updateProgress() {
    const total = lessons.length;
    const seen = lessons.filter((l) => state.seen[l.n]).length;
    const pct = total ? Math.round((seen / total) * 100) : 0;
    els.progTxt.textContent = `${seen} / ${total}`;
    els.ringPct.textContent = pct + '%';
    els.ringFg.style.strokeDashoffset = String(163.36 * (1 - (total ? seen / total : 0)));
    const withVideo = lessons.filter((l) => l.video).length;
    els.heroSub.textContent = `${total} ta mavzu · ${withVideo} tasida video bor`;
    if (state.last && byN[state.last]) {
      els.cont.hidden = false;
      els.contTitle.textContent = `${state.last}. ${byN[state.last].title}`;
    } else {
      els.cont.hidden = true;
    }
  }

  function markSeen(n) {
    state.seen[n] = true;
    state.last = n;
    const g = groupOf[n];
    let finished = null;
    if (g && !state.done[g.id] && g.items.every((k) => state.seen[k])) {
      state.done[g.id] = true;
      finished = g;
    }
    save();
    document.querySelectorAll(`.card[data-n="${n}"]`).forEach((c) => c.classList.add('seen'));
    updateProgress();
    if (finished) {
      setTimeout(() => { toast(`🎉 ${finished.name} bo'limi tugadi!`); Sfx.win(); }, 700);
    }
  }

  /* ---------------- rendering ---------------- */
  function renderChips() {
    const mk = (id, label, count) =>
      `<button class="chip${filterGroup === id ? ' on' : ''}" type="button" data-g="${esc(id)}">${label}<em data-count="${esc(id)}">${count}</em></button>`;
    els.chips.innerHTML =
      mk('all', 'Hammasi', lessons.length) +
      groups.map((g) => mk(g.id, `${g.icon} ${esc(g.name)}`, g.items.length)).join('');
  }
  function renderList() {
    const q = norm(query.trim());
    let idx = 0, html = '';
    groups.forEach((g) => {
      if (filterGroup !== 'all' && filterGroup !== g.id) return;
      const items = g.items.map((n) => byN[n]).filter((l) => l && (!q || norm(l.title).includes(q) || String(l.n) === q));
      if (!items.length) return;
      const seen = g.items.filter((n) => state.seen[n]).length;
      html += `<div class="gh" style="--c:${esc(g.color)}"><span class="gi">${g.icon}</span><b>${esc(g.name)}</b><small>${seen}/${g.items.length}</small></div><div class="grid">`;
      items.forEach((l) => {
        html += `<button class="card${state.seen[l.n] ? ' seen' : ''}" type="button" data-n="${l.n}" style="--c:${esc(g.color)};--i:${Math.min(idx++, 14)}">` +
          `<span class="ico">${esc(l.icon)}</span>` +
          `<span class="txt"><b>${esc(l.title)}</b><em><span class="pill">№${l.n}</span>` +
          (l.video ? '<span class="pill v">🎬 Video</span>' : '') +
          '<span class="pill ok">✓ Ko\'rilgan</span></em></span><span class="chev">›</span></button>';
      });
      html += '</div>';
    });
    els.list.innerHTML = html || '<div class="empty"><b>🔍</b>Hech narsa topilmadi.<br>Boshqa so\'z bilan urinib ko\'ring.</div>';
  }

  /* ---------------- lesson screen ---------------- */
  function stopVideo() {
    clearTimeout(vTimer);
    const v = els.vpanel.querySelector('video');
    if (v) { try { v.pause(); } catch (e) { /* ignore */ } v.removeAttribute('src'); v.load(); }
    els.vpanel.innerHTML = '';
    els.vpanel.classList.remove('on');
  }

  function setTab(which, silent) {
    const l = byN[cur];
    if (!l) return;
    const wantVideo = which === 'video' && !!l.video;
    els.tabs.classList.toggle('v', wantVideo);
    els.tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.tab === (wantVideo ? 'video' : 'lesson')));
    if (!silent) Sfx.tick();
    if (wantVideo) {
      if (!els.vpanel.firstChild) {
        els.vpanel.innerHTML =
          `<video controls playsinline autoplay preload="auto" src="${esc(l.video)}"></video><p>🎬 ${esc(l.title)} — simulyatsiya videosi</p>`;
        const v = els.vpanel.querySelector('video');
        v.addEventListener('error', () => {
          els.vpanel.innerHTML = '<p>Videoni ochib bo\'lmadi.</p>';
        });
      }
      els.vpanel.classList.add('on');
    } else {
      stopVideo();
    }
  }

  function neighbour(step) {
    const i = order.indexOf(cur);
    return i < 0 ? 0 : (order[i + step] || 0);
  }

  function openLesson(n, fromNav) {
    const l = byN[n];
    if (!l) return;
    stopVideo();
    cur = n;
    els.lTitle.textContent = `${l.n}. ${l.title}`;
    els.lGroup.textContent = groupOf[n] ? `${groupOf[n].icon} ${groupOf[n].name}` : '';
    els.tabs.hidden = !l.video;
    els.tabs.classList.remove('v');
    els.tabs.querySelectorAll('button').forEach((b) => b.classList.toggle('on', b.dataset.tab === 'lesson'));
    els.prev.disabled = !neighbour(-1);
    els.next.disabled = !neighbour(1);

    els.spin.classList.remove('off');
    els.frame.classList.remove('ready');
    els.frame.src = l.file;

    if (!fromNav) {
      els.home.classList.add('behind');
      els.lesson.classList.add('active');
    }
    Sfx.open();
    markSeen(n);
  }

  function goHome() {
    stopVideo();
    cur = 0;
    els.lesson.classList.remove('active');
    els.home.classList.remove('behind');
    setTimeout(() => { if (!cur) els.frame.src = 'about:blank'; }, 420);
    updateProgress();
    renderList();
  }

  els.frame.addEventListener('load', () => {
    if (!cur) return;
    els.spin.classList.add('off');
    els.frame.classList.add('ready');
    try { // lesson pages are same-origin: give their buttons the same tap sound
      const doc = els.frame.contentDocument;
      if (doc && !doc.__s6) {
        doc.__s6 = true;
        doc.addEventListener('click', (e) => {
          if (e.target.closest && e.target.closest('button,a,select,summary,label,input[type=radio],input[type=checkbox]')) Sfx.tap();
        }, true);
      }
    } catch (e) { /* cross-origin or blank: skip */ }
  });

  // app sent to background: stop video so it does not keep playing behind the scenes
  document.addEventListener('visibilitychange', () => {
    if (document.hidden) { const v = els.vpanel.querySelector('video'); if (v) { try { v.pause(); } catch (e) { /* ignore */ } } }
  });

  /* Called by the native shell on the Android back button.
     Returns true if the web layer handled it, false if the app should close. */
  window.appBack = () => {
    if (cur) { Sfx.back(); goHome(); return true; }
    if (query || filterGroup !== 'all') {
      query = ''; els.q.value = ''; els.qClear.hidden = true; filterGroup = 'all';
      renderChips(); renderList(); els.homeScroll.scrollTop = 0;
      return true;
    }
    return false;
  };

  /* ---------------- events ---------------- */
  els.list.addEventListener('click', (e) => {
    const c = e.target.closest('.card');
    if (c) openLesson(+c.dataset.n);
  });
  els.cont.addEventListener('click', () => { if (state.last) openLesson(state.last); });
  els.chips.addEventListener('click', (e) => {
    const b = e.target.closest('.chip');
    if (!b) return;
    filterGroup = b.dataset.g;
    Sfx.tick();
    renderChips();
    renderList();
  });
  els.q.addEventListener('input', () => {
    query = els.q.value;
    els.qClear.hidden = !query;
    renderList();
  });
  els.qClear.addEventListener('click', () => { query = ''; els.q.value = ''; els.qClear.hidden = true; Sfx.tap(); renderList(); els.q.focus(); });
  els.back.addEventListener('click', () => { Sfx.back(); goHome(); });
  els.prev.addEventListener('click', () => { const n = neighbour(-1); if (n) openLesson(n, true); });
  els.next.addEventListener('click', () => { const n = neighbour(1); if (n) openLesson(n, true); });
  els.tabs.addEventListener('click', (e) => {
    const b = e.target.closest('button');
    if (b) setTab(b.dataset.tab);
  });
  els.sound.addEventListener('click', () => {
    state.sound = !state.sound;
    els.sound.textContent = state.sound ? '🔊' : '🔇';
    save();
    if (state.sound) Sfx.tap();
  });
  els.sound.textContent = state.sound ? '🔊' : '🔇';

  /* ---------------- boot ---------------- */
  const started = Date.now();
  function hideSplash() {
    if (els.splash.classList.contains('hide')) return;
    els.splash.classList.add('hide');
    setTimeout(() => els.splash.remove(), 700);
  }
  els.splash.addEventListener('click', hideSplash);

  fetch('lessons.json')
    .then((r) => { if (!r.ok) throw new Error('HTTP ' + r.status); return r.json(); })
    .then((data) => {
      groups = data.groups;
      lessons = data.lessons;
      lessons.forEach((l) => { byN[l.n] = l; });
      groups.forEach((g) => g.items.forEach((n) => { groupOf[n] = g; order.push(n); }));
      renderChips();
      renderList();
      updateProgress();
      Sfx.chime();
      setTimeout(hideSplash, Math.max(200, 1700 - (Date.now() - started)));
    })
    .catch((err) => {
      els.heroSub.textContent = 'Xatolik: darslar ro\'yxati o\'qilmadi';
      els.list.innerHTML = `<div class="empty"><b>⚠️</b>${esc(err.message)}</div>`;
      hideSplash();
    });
})();
