# 6-sinf darslar (offline Android ilova)

22 ta interaktiv dars va 20 ta video, internetsiz ishlaydi. Dars sahifalari `app/src/main/assets/www/lessons/`,
videolar `.../videos/` papkasida, menyu `lessons.json` dan o'qiladi.

## APK olish (kompyutersiz, telefondan ham bo'ladi)
1. github.com da bo'sh repo oching (masalan `sinf6-darslar`).
2. Shu papkadagi hamma narsani (yashirin `.github` papkasi bilan) repoga yuklang.
3. Repo → **Actions** → **Build APK** ishga tushadi (yoki *Run workflow*). 3–6 daqiqa.
4. Tugagach, run sahifasining pastidagi **Artifacts → 6-sinf-darslar-apk** ni yuklab oling, zip ichida `app-debug.apk`.
5. Telefonda APK ni oching, "noma'lum manbalardan o'rnatish"ga ruxsat bering.

## Kompyuterda
JDK 17 + Android SDK (platform 34) + Gradle 8.7 bo'lsa: `gradle assembleDebug`
→ `app/build/outputs/apk/debug/app-debug.apk`.
Android Studio: papkani oching; Gradle wrapper yo'q deb shikoyat qilsa, bir marta `gradle wrapper --gradle-version 8.7` bajaring.

## Menyu bo'limlarini o'zgartirish
`tools/extract_lessons.py` ichidagi `GROUPS` ro'yxati (bo'lim nomi, ikonka, rang, dars raqamlari).
Asl HTML yangilansa: `python3 tools/extract_lessons.py yangi_fayl.html` (ffprobe bo'lsa videolarni tekshiradi).

## Eslatma
Bu APK *debug* kalit bilan imzolangan: o'rnatish va tarqatishga yetadi, Google Play uchun release imzo kerak bo'ladi.
