#!/usr/bin/env python3
"""Splits the single-file lesson collection into app assets.

Usage: python3 tools/extract_lessons.py path/to/original.html

Writes into app/src/main/assets/www/:
  lessons/NN.html   one standalone page per lesson (iframe source)
  videos/NN.mp4     the base64 <script id="vK"> blobs decoded to real mp4 files
  lessons.json      metadata + menu groups consumed by app.js

Lesson titles, icons and the lesson-to-video mapping come from the original
file (const L=[{t,i,h,v}]). Only the menu GROUPS below are an editorial choice.
"""
import base64
import json
import re
import subprocess
import sys
from pathlib import Path

# Original lesson numbers (1-based); original order is kept inside each group.
GROUPS = [
    {"id": "bio", "name": "Biologiya", "icon": "🧬", "color": "#16a34a", "items": [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 12]},
    {"id": "mat", "name": "Moddalar va xossalari", "icon": "🧪", "color": "#9333ea", "items": [13, 14, 15, 16, 17]},
    {"id": "fiz", "name": "Fizika", "icon": "⚡", "color": "#ea580c", "items": [18, 19, 20]},
    {"id": "yer", "name": "Yer va tog' jinslari", "icon": "🪨", "color": "#b45309", "items": [21, 22]},
    {"id": "bsb", "name": "Nazorat (BSB)", "icon": "📝", "color": "#dc2626", "items": [11]},
]


def main(src: str) -> None:
    root = Path(__file__).resolve().parent.parent / "app/src/main/assets/www"
    (root / "lessons").mkdir(parents=True, exist_ok=True)
    (root / "videos").mkdir(parents=True, exist_ok=True)
    s = Path(src).read_text(encoding="utf-8")

    start = s.index("const L=") + len("const L=")
    lessons, _ = json.JSONDecoder().raw_decode(s[start:])

    blobs = {
        int(m.group(1)): m.group(2)
        for m in re.finditer(r'<script type="text/plain" id="v(\d+)">(.*?)</script>', s, re.S)
    }

    flat = sorted(n for g in GROUPS for n in g["items"])
    assert flat == list(range(1, len(lessons) + 1)), (
        f"GROUPS must cover 1..{len(lessons)} exactly once, got {flat}"
    )

    meta = []
    for idx, x in enumerate(lessons):
        n = idx + 1
        html = x["h"]
        # Offline: drop the Google Fonts <link>; the CSS already falls back to system-ui.
        html = re.sub(r'<link[^>]*fonts\.googleapis\.com[^>]*>\s*', "", html)
        (root / "lessons" / f"{n:02d}.html").write_text(html, encoding="utf-8")
        video = None
        if x.get("v", -1) >= 0:
            data = base64.b64decode(blobs[x["v"]].strip())
            out = root / "videos" / f"{n:02d}.mp4"
            out.write_bytes(data)
            video = f"videos/{n:02d}.mp4"
        meta.append({
            "n": n,
            "title": x["t"],
            "icon": x["i"],
            "file": f"lessons/{n:02d}.html",
            "video": video,
        })

    (root / "lessons.json").write_text(
        json.dumps({"groups": GROUPS, "lessons": meta}, ensure_ascii=False, indent=1),
        encoding="utf-8",
    )

    bad = []
    for m in meta:
        if m["video"]:
            r = subprocess.run(
                ["ffprobe", "-v", "error", "-show_entries", "stream=codec_name", "-of", "csv=p=0",
                 str(root / m["video"])],
                capture_output=True, text=True,
            )
            if "h264" not in r.stdout:
                bad.append((m["video"], r.stdout.strip(), r.stderr.strip()))
    print(f"{len(meta)} lessons, {sum(1 for m in meta if m['video'])} videos written to {root}")
    if bad:
        print("WARNING: not h264 / unreadable:", bad)


if __name__ == "__main__":
    if len(sys.argv) != 2:
        sys.exit(__doc__)
    main(sys.argv[1])
