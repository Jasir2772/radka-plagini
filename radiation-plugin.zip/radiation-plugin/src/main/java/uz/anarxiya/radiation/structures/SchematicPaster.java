package uz.anarxiya.radiation.structures;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.regions.Region;
import com.sk89q.worldedit.session.ClipboardHolder;
import org.bukkit.HeightMap;
import org.bukkit.World;
import uz.anarxiya.radiation.RadiationPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.util.logging.Level;

/**
 * WorldEdit/FAWE orqali .schem fayllarni joylashtiradi.
 * DIQQAT: bu klass faqat WorldEdit yoqilgan bo'lsagina yaratiladi (StructureManager tekshiradi).
 */
public class SchematicPaster {

    public record PasteResult(int minX, int minY, int minZ, int maxX, int maxY, int maxZ, int groundY) {}

    private final RadiationPlugin plugin;

    public SchematicPaster(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    /** Sxematikni (x, z) ustiga joylaydi. Muvaffaqiyatsiz bo'lsa null. */
    public PasteResult paste(File file, World bukkitWorld, int x, int z) {
        try {
            ClipboardFormat format = ClipboardFormats.findByFile(file);
            if (format == null) {
                plugin.getLogger().warning("Sxematik formati aniqlanmadi: " + file.getName());
                return null;
            }

            Clipboard clipboard;
            try (FileInputStream in = new FileInputStream(file);
                 ClipboardReader reader = format.getReader(in)) {
                clipboard = reader.read();
            }

            int groundY = bukkitWorld.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            if (bukkitWorld.getBlockAt(x, groundY, z).isLiquid()) return null; // suv/okean ustiga qurmaymiz

            com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(bukkitWorld);
            BlockVector3 to = BlockVector3.at(x, groundY, z);

            try (EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder()
                    .world(weWorld).maxBlocks(-1).build()) {
                Operation operation = new ClipboardHolder(clipboard)
                        .createPaste(editSession)
                        .to(to)
                        .ignoreAirBlocks(true)
                        .build();
                Operations.complete(operation);
            }

            // Joylashgan hududning haqiqiy chegaralari (clipboard origin'ini hisobga olgan holda)
            Region region = clipboard.getRegion();
            BlockVector3 offset = to.subtract(clipboard.getOrigin());
            BlockVector3 min = region.getMinimumPoint().add(offset);
            BlockVector3 max = region.getMaximumPoint().add(offset);

            return new PasteResult(min.getBlockX(), min.getBlockY(), min.getBlockZ(),
                    max.getBlockX(), max.getBlockY(), max.getBlockZ(), groundY);
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Sxematikni joylashtirishda xatolik: " + file.getName(), e);
            return null;
        }
    }
}
