package uz.anarxiya.radiation.hooks;

import io.lumine.mythic.bukkit.BukkitAdapter;
import io.lumine.mythic.bukkit.MythicBukkit;
import org.bukkit.Location;
import org.bukkit.entity.Entity;

/**
 * MythicMobs 5.x API bilan to'g'ridan-to'g'ri ishlaydi.
 * DIQQAT: bu klass faqat MythicMobs serverda yoqilgan bo'lsagina yaratilishi kerak
 * (MobManager shuni tekshiradi), aks holda NoClassDefFoundError chiqadi.
 */
public class MythicHook {

    /** MythicMobs'da shu nomli mob bormi */
    public boolean hasMob(String mobId) {
        return MythicBukkit.inst().getMobManager().getMythicMob(mobId).isPresent();
    }

    /** Mobni chaqiradi. Mob topilmasa yoki chaqirilmasa null qaytaradi. */
    public Entity spawn(String mobId, Location location, double level) {
        var optional = MythicBukkit.inst().getMobManager().getMythicMob(mobId);
        if (optional.isEmpty()) return null;

        var activeMob = optional.get().spawn(BukkitAdapter.adapt(location), level);
        if (activeMob == null) return null;

        return activeMob.getEntity().getBukkitEntity();
    }
}
