package uz.anarxiya.radiation.util;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;

import java.util.ArrayList;
import java.util.List;

/** Rang kodlari (& va §) bilan ishlash uchun yordamchi metodlar */
public final class Text {

    private Text() {}

    public static String color(String s) {
        return s == null ? "" : s.replace('&', '§');
    }

    public static List<String> color(List<String> list) {
        List<String> out = new ArrayList<>();
        for (String s : list) out.add(color(s));
        return out;
    }

    /** § kodli matnni Adventure Component ga aylantiradi (actionbar/title uchun ishonchli) */
    public static Component component(String s) {
        return LegacyComponentSerializer.legacySection().deserialize(color(s));
    }
}
