package uz.anarxiya.radiation.managers;

import com.sk89q.worldedit.EditSession;
import com.sk89q.worldedit.WorldEdit;
import com.sk89q.worldedit.bukkit.BukkitAdapter;
import com.sk89q.worldedit.extent.clipboard.Clipboard;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormat;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardFormats;
import com.sk89q.worldedit.extent.clipboard.io.ClipboardReader;
import com.sk89q.worldedit.function.operation.Operation;
import com.sk89q.worldedit.function.operation.Operations;
import com.sk89q.worldedit.math.BlockVector3;
import com.sk89q.worldedit.session.ClipboardHolder;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import uz.anarxiya.radiation.RadiationPlugin;

import java.io.File;
import java.io.FileInputStream;
import java.util.*;
import java.util.logging.Level;

public class StructureManager {

    private final RadiationPlugin plugin;
    private final LootManager lootManager;
    private final Random random = new Random();
    private final List<int[]> placedLocations = new ArrayList<>(); // [x, z] markazlari, overlap tekshiruv uchun
    private boolean worldEditAvailable;

    public StructureManager(RadiationPlugin plugin, LootManager lootManager) {
        this.plugin = plugin;
        this.lootManager = lootManager;
        this.worldEditAvailable = Bukkit.getPluginManager().isPluginEnabled("WorldEdit")
                || Bukkit.getPluginManager().isPluginEnabled("FastAsyncWorldEdit");
    }

    /** Dunyo reset qilinganda barcha strukturalarni qayta joylashtiradi */
    public void generateAll(World world) {
        if (!plugin.getConfig().getBoolean("structures.enabled", true)) return;
        placedLocations.clear();

        if (!worldEditAvailable) {
            plugin.getLogger().warning("WorldEdit/FAWE topilmadi - strukturalar joylashtirilmaydi. " +
                    "Iltimos WorldEdit yoki FastAsyncWorldEdit o'rnating.");
            return;
        }

        List<String> schematics = plugin.getConfig().getStringList("structures.list");
        if (schematics.isEmpty()) return;

        String folderName = plugin.getConfig().getString("structures.schematics-folder", "schematics");
        File schematicsFolder = new File(plugin.getDataFolder(), folderName);
        int attempts = plugin.getConfig().getInt("structures.attempts-per-reset", 40);
        int minDistance = plugin.getConfig().getInt("structures.min-distance-between", 150);

        int placed = 0;
        for (int i = 0; i < attempts; i++) {
            String schemName = schematics.get(random.nextInt(schematics.size()));
            File schemFile = new File(schematicsFolder, schemName);
            if (!schemFile.exists()) continue;

            int[] pos = randomPositionInWorld();
            if (isTooClose(pos, minDistance)) continue;

            Location loc = new Location(world, pos[0], 0, pos[1]);
            int[] bounds = pasteSchematic(schemFile, loc);
            if (bounds != null) {
                placedLocations.add(pos);
                placed++;
                // Struktura ichidagi sandiqlarni loot bilan to'ldirish
                lootManager.fillChestsInRegion(world, bounds[0], bounds[1], bounds[2], bounds[3], bounds[4], bounds[5]);
            }
        }
        plugin.getLogger().info(placed + " ta struktura muvaffaqiyatli joylashtirildi.");
    }

    /** Sxematik faylni berilgan joyga joylashtiradi, [minX,minY,minZ,maxX,maxY,maxZ] qaytaradi */
    private int[] pasteSchematic(File file, Location location) {
        try {
            ClipboardFormat format = ClipboardFormats.findByFile(file);
            if (format == null) return null;

            Clipboard clipboard;
            try (ClipboardReader reader = format.getReader(new FileInputStream(file))) {
                clipboard = reader.read();
            }

            World bukkitWorld = location.getWorld();
            com.sk89q.worldedit.world.World weWorld = BukkitAdapter.adapt(bukkitWorld);

            // Eng balandroq blokka joylashtirish uchun Y ni topamiz
            int highestY = bukkitWorld.getHighestBlockYAt(location.getBlockX(), location.getBlockZ());
            BlockVector3 to = BlockVector3.at(location.getBlockX(), highestY, location.getBlockZ());

            try (EditSession editSession = WorldEdit.getInstance().newEditSessionBuilder()
                    .world(weWorld).maxBlocks(-1).build()) {
                Operation operation = new ClipboardHolder(clipboard)
                        .createPaste(editSession)
                        .to(to)
                        .ignoreAirBlocks(true)
                        .build();
                Operations.complete(operation);
            }

            BlockVector3 dim = clipboard.getDimensions();
            return new int[]{
                    to.getBlockX(), to.getBlockY(), to.getBlockZ(),
                    to.getBlockX() + dim.getBlockX(), to.getBlockY() + dim.getBlockY(), to.getBlockZ() + dim.getBlockZ()
            };
        } catch (Exception e) {
            plugin.getLogger().log(Level.WARNING, "Sxematikni joylashtirishda xatolik: " + file.getName(), e);
            return null;
        }
    }

    private int[] randomPositionInWorld() {
        int centerX = plugin.getConfig().getInt("world.center-x", 0);
        int centerZ = plugin.getConfig().getInt("world.center-z", 0);
        int size = plugin.getConfig().getInt("world.size", 10000);
        int radius = size / 2;

        int x = centerX + random.nextInt(radius * 2) - radius;
        int z = centerZ + random.nextInt(radius * 2) - radius;
        return new int[]{x, z};
    }

    private boolean isTooClose(int[] pos, int minDistance) {
        for (int[] existing : placedLocations) {
            double dx = pos[0] - existing[0];
            double dz = pos[1] - existing[1];
            if (Math.sqrt(dx * dx + dz * dz) < minDistance) return true;
        }
        return false;
    }
}
