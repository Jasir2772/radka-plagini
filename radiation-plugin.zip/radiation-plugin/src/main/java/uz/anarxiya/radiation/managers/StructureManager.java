package uz.anarxiya.radiation.managers;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.event.ClickEvent;
import net.kyori.adventure.text.event.HoverEvent;
import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.structures.ProceduralBuilder;
import uz.anarxiya.radiation.structures.SchematicPaster;
import uz.anarxiya.radiation.util.Text;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.logging.Level;

/**
 * Dunyo reset bo'lganda strukturalarni joylashtiradi:
 *  - protsedura strukturalar (kod orqali, WorldEdit shart emas)
 *  - sxematik (.schem) strukturalar (WorldEdit/FAWE bo'lsa)
 * Joylashgan strukturalar ro'yxati structures.yml faylida saqlanadi (qo'riqchi moblar uchun).
 */
public class StructureManager {

    /** Joylashgan struktura: tur, x, yer sathi y, z */
    public record PlacedStructure(String type, int x, int y, int z) {
        public String key() {
            return x + "," + y + "," + z;
        }
    }

    private record Candidate(boolean schematic, String name, int weight) {}

    private final RadiationPlugin plugin;
    private final LootManager lootManager;
    private final Random random = new Random();
    private final List<PlacedStructure> placed = new ArrayList<>();
    private final File registryFile;
    private SchematicPaster schematicPaster; // WorldEdit bo'lmasa null
    private BukkitTask buildTask;

    public StructureManager(RadiationPlugin plugin, LootManager lootManager) {
        this.plugin = plugin;
        this.lootManager = lootManager;
        this.registryFile = new File(plugin.getDataFolder(), "structures.yml");

        boolean worldEdit = Bukkit.getPluginManager().isPluginEnabled("WorldEdit")
                || Bukkit.getPluginManager().isPluginEnabled("FastAsyncWorldEdit");
        if (worldEdit) {
            try {
                this.schematicPaster = new SchematicPaster(plugin);
            } catch (Throwable t) {
                plugin.getLogger().warning("WorldEdit topildi, lekin ulab bo'lmadi: " + t.getMessage());
            }
        }
        loadRegistry();
    }

    public List<PlacedStructure> getPlaced() {
        return Collections.unmodifiableList(placed);
    }

    public boolean isBusy() {
        return buildTask != null;
    }

    public boolean hasSchematicSupport() {
        return schematicPaster != null;
    }

    /** Struktura turi uchun qo'riqchilar soni */
    public int getGuardCount(String type) {
        if ("schematic".equals(type)) {
            return plugin.getConfig().getInt("structures.schematic-guards", 2);
        }
        return plugin.getConfig().getInt("structures.procedural.types." + type + ".guards", 1);
    }

    public void cancelTasks() {
        if (buildTask != null) {
            buildTask.cancel();
            buildTask = null;
        }
    }

    /** Dunyo reset qilinganda: eski ro'yxatni tozalab, hammasini qaytadan joylashtiradi */
    public void generateAll(World world) {
        placed.clear();
        saveRegistry();
        generate(world);
    }

    /** Mavjud strukturalarni o'chirmasdan, qo'shimcha strukturalar joylashtiradi (masalan /radiation structures generate) */
    public void generate(World world) {
        if (!plugin.getConfig().getBoolean("structures.enabled", true)) return;
        if (buildTask != null) {
            plugin.getLogger().warning("Strukturalar joylashtirish allaqachon davom etmoqda.");
            return;
        }

        boolean proceduralOn = plugin.getConfig().getBoolean("structures.procedural.enabled", true);
        ConfigurationSection types = plugin.getConfig().getConfigurationSection("structures.procedural.types");
        List<String> schematics = availableSchematics();

        if (!proceduralOn && schematics.isEmpty()) {
            plugin.getLogger().warning("Joylashtirish uchun struktura yo'q: protsedura strukturalar o'chirilgan " +
                    "va .schem fayllar topilmadi.");
            return;
        }
        if (schematics.isEmpty() && plugin.getConfig().getStringList("structures.list").size() > 0
                && schematicPaster == null) {
            plugin.getLogger().info("WorldEdit yo'q - faqat protsedura strukturalar qo'llaniladi.");
        }

        int attempts = plugin.getConfig().getInt("structures.attempts-per-reset", 60);
        long interval = Math.max(1L, plugin.getConfig().getLong("structures.placement-interval-ticks", 10L));
        int maxDiff = plugin.getConfig().getInt("structures.max-height-difference", 4);

        int[] counter = {0};
        Map<String, Integer> stats = new TreeMap<>();

        buildTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            // dunyo o'chirilgan bo'lsa (masalan yangi reset), to'xtaymiz
            if (!Bukkit.getWorlds().contains(world)) {
                stopBuild(stats);
                return;
            }
            if (counter[0] >= attempts) {
                stopBuild(stats);
                return;
            }
            counter[0]++;
            try {
                String placedType = attemptOne(world, schematics, proceduralOn ? types : null, maxDiff);
                if (placedType != null) stats.merge(placedType, 1, Integer::sum);
            } catch (Throwable t) {
                plugin.getLogger().log(Level.WARNING, "Struktura joylashtirishda xatolik", t);
            }
        }, 20L, interval);
    }

    private void stopBuild(Map<String, Integer> stats) {
        cancelTasks();
        int total = stats.values().stream().mapToInt(Integer::intValue).sum();
        plugin.getLogger().info(total + " ta struktura joylashtirildi " + stats);
        notifyAdmins(Text.component(plugin.msg("structure-done", "{total}", String.valueOf(total), "{stats}", stats.toString())));
    }

    /** Bitta struktura joylashtirishga urinadi. Muvaffaqiyatli bo'lsa struktura turini, aks holda null qaytaradi. */
    private String attemptOne(World world, List<String> schematics, ConfigurationSection types, int maxDiff) {
        int[] pos = randomPosition();

        int centerX = plugin.getConfig().getInt("world.center-x", 0);
        int centerZ = plugin.getConfig().getInt("world.center-z", 0);
        double distFromCenter = Math.hypot(pos[0] - centerX, pos[1] - centerZ);
        if (distFromCenter < plugin.getConfig().getInt("structures.min-distance-from-center", 120)) return null;
        if (isTooClose(pos, plugin.getConfig().getInt("structures.min-distance-between", 150))) return null;

        int ring = Math.min(plugin.getRadiationManager().getRingAt(pos[0], pos[1]), 4);

        List<Candidate> candidates = new ArrayList<>();
        if (types != null) {
            for (String type : types.getKeys(false)) {
                if (!ProceduralBuilder.TYPES.contains(type)) continue;
                ConfigurationSection section = types.getConfigurationSection(type);
                if (section == null) continue;
                int weight = section.getInt("weight", 10);
                if (weight <= 0) continue;
                List<Integer> rings = section.getIntegerList("rings");
                if (!rings.isEmpty() && !rings.contains(ring)) continue;
                candidates.add(new Candidate(false, type, weight));
            }
        }
        int schematicWeight = plugin.getConfig().getInt("structures.schematic-weight", 20);
        if (schematicWeight > 0) {
            for (String name : schematics) candidates.add(new Candidate(true, name, schematicWeight));
        }
        if (candidates.isEmpty()) return null;

        Candidate pick = weightedPick(candidates);

        if (!pick.schematic()) {
            ProceduralBuilder builder = new ProceduralBuilder(world, random, maxDiff);
            ProceduralBuilder.Result result = builder.build(pick.name(), pos[0], pos[1]);
            if (result == null) return null;

            for (Location location : result.containers()) {
                lootManager.fillContainer(location, pick.name());
            }
            register(new PlacedStructure(pick.name(), result.anchorX(), result.groundY(), result.anchorZ()));
            return pick.name();
        }

        // Sxematik struktura
        File folder = new File(plugin.getDataFolder(), plugin.getConfig().getString("structures.schematics-folder", "schematics"));
        SchematicPaster.PasteResult paste = schematicPaster.paste(new File(folder, pick.name()), world, pos[0], pos[1]);
        if (paste == null) return null;

        register(new PlacedStructure("schematic", pos[0], paste.groundY(), pos[1]));

        // FAWE bloklarni asinxron qo'yishi mumkin, shuning uchun sandiqlarni biroz kutib to'ldiramiz
        Bukkit.getScheduler().runTaskLater(plugin, () -> lootManager.fillContainersInRegion(
                world, paste.minX(), paste.minY(), paste.minZ(),
                paste.maxX(), paste.maxY(), paste.maxZ(), "schematic"), 60L);
        return "schematic";
    }

    private Candidate weightedPick(List<Candidate> candidates) {
        int total = 0;
        for (Candidate c : candidates) total += c.weight();
        int roll = random.nextInt(total);
        for (Candidate c : candidates) {
            roll -= c.weight();
            if (roll < 0) return c;
        }
        return candidates.get(0);
    }

    /** config'dagi ro'yxatdan faqat haqiqatan mavjud .schem fayllarni qaytaradi (WorldEdit bo'lsa) */
    private List<String> availableSchematics() {
        List<String> result = new ArrayList<>();
        if (schematicPaster == null) return result;

        File folder = new File(plugin.getDataFolder(), plugin.getConfig().getString("structures.schematics-folder", "schematics"));
        for (String name : plugin.getConfig().getStringList("structures.list")) {
            if (new File(folder, name).isFile()) result.add(name);
        }
        return result;
    }

    private int[] randomPosition() {
        int centerX = plugin.getConfig().getInt("world.center-x", 0);
        int centerZ = plugin.getConfig().getInt("world.center-z", 0);
        int size = plugin.getConfig().getInt("world.size", 10000);
        int radius = Math.max(100, size / 2 - 80); // chegara yonida qurmaslik uchun

        int x = centerX + random.nextInt(radius * 2 + 1) - radius;
        int z = centerZ + random.nextInt(radius * 2 + 1) - radius;
        return new int[]{x, z};
    }

    private boolean isTooClose(int[] pos, int minDistance) {
        for (PlacedStructure s : placed) {
            if (Math.hypot(pos[0] - s.x(), pos[1] - s.z()) < minDistance) return true;
        }
        return false;
    }

    // ---------- Ro'yxatni saqlash / yuklash (structures.yml) ----------

    private void register(PlacedStructure structure) {
        placed.add(structure);
        saveRegistry();

        if (plugin.getConfig().getBoolean("structures.notify.console", true)) {
            plugin.getLogger().info("Struktura: " + structure.type() + " (" + structure.x() + " " + structure.y() + " " + structure.z() + ")");
        }
        notifyAdmins(describe(structure));
    }

    /** Struktura haqida bosiladigan qator: turi, zona, koordinata. Bosilsa /radiation tp ishlaydi. */
    public Component describe(PlacedStructure s) {
        int ring = Math.min(plugin.getRadiationManager().getRingAt(s.x(), s.z()), 4);
        String text = plugin.msg("structure-placed", "{type}", s.type(), "{ring}", String.valueOf(ring),
                "{x}", String.valueOf(s.x()), "{y}", String.valueOf(s.y()), "{z}", String.valueOf(s.z()));
        return Text.component(text)
                .hoverEvent(HoverEvent.showText(Text.component(plugin.msg("structure-hover"))))
                .clickEvent(ClickEvent.runCommand("/radiation tp " + s.x() + " " + s.y() + " " + s.z()));
    }

    private void notifyAdmins(Component message) {
        if (!plugin.getConfig().getBoolean("structures.notify.chat", true)) return;
        String permission = plugin.getConfig().getString("structures.notify.permission", "radiation.admin");
        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.hasPermission(permission)) player.sendMessage(message);
        }
    }

    private void saveRegistry() {
        YamlConfiguration yaml = new YamlConfiguration();
        List<String> lines = new ArrayList<>();
        for (PlacedStructure s : placed) {
            lines.add(s.type() + ";" + s.x() + ";" + s.y() + ";" + s.z());
        }
        yaml.set("structures", lines);
        try {
            if (!plugin.getDataFolder().exists()) plugin.getDataFolder().mkdirs();
            yaml.save(registryFile);
        } catch (IOException e) {
            plugin.getLogger().warning("structures.yml ni saqlab bo'lmadi: " + e.getMessage());
        }
    }

    private void loadRegistry() {
        if (!registryFile.exists()) return;
        YamlConfiguration yaml = YamlConfiguration.loadConfiguration(registryFile);
        for (String line : yaml.getStringList("structures")) {
            String[] p = line.split(";");
            if (p.length != 4) continue;
            try {
                placed.add(new PlacedStructure(p[0], Integer.parseInt(p[1]), Integer.parseInt(p[2]), Integer.parseInt(p[3])));
            } catch (NumberFormatException ignored) {
            }
        }
    }
}
