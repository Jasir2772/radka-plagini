package uz.anarxiya.radiation;

import org.bukkit.Bukkit;
import org.bukkit.plugin.java.JavaPlugin;
import uz.anarxiya.radiation.commands.RadiationCommand;
import uz.anarxiya.radiation.listeners.WorldEnterListener;
import uz.anarxiya.radiation.managers.*;

public class RadiationPlugin extends JavaPlugin {

    private static RadiationPlugin instance;

    private WorldManager worldManager;
    private RadiationManager radiationManager;
    private MobManager mobManager;
    private StructureManager structureManager;
    private LootManager lootManager;
    private SuitManager suitManager;

    @Override
    public void onEnable() {
        instance = this;
        saveDefaultConfig();

        // Manager'larni ishga tushirish
        this.suitManager = new SuitManager(this);
        this.lootManager = new LootManager(this);
        this.structureManager = new StructureManager(this, lootManager);
        this.worldManager = new WorldManager(this, structureManager);
        this.radiationManager = new RadiationManager(this, suitManager);
        this.mobManager = new MobManager(this);

        // Komandalar
        RadiationCommand cmd = new RadiationCommand(this, worldManager, suitManager);
        getCommand("radiation").setExecutor(cmd);
        getCommand("radiation").setTabCompleter(cmd);

        // Listenerlar
        Bukkit.getPluginManager().registerEvents(new WorldEnterListener(this), this);

        // Doimiy tekshiruv tasklarini boshlash
        radiationManager.start();
        mobManager.start();
        worldManager.scheduleAutoReset();

        getLogger().info("RadiationZone plugin yoqildi! world1 nazorat ostida.");
    }

    @Override
    public void onDisable() {
        if (radiationManager != null) radiationManager.stop();
        if (mobManager != null) mobManager.stop();
        if (worldManager != null) worldManager.cancelTasks();
        getLogger().info("RadiationZone plugin o'chirildi.");
    }

    public static RadiationPlugin get() {
        return instance;
    }

    public WorldManager getWorldManager() { return worldManager; }
    public RadiationManager getRadiationManager() { return radiationManager; }
    public MobManager getMobManager() { return mobManager; }
    public StructureManager getStructureManager() { return structureManager; }
    public LootManager getLootManager() { return lootManager; }
    public SuitManager getSuitManager() { return suitManager; }
}
