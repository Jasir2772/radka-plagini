package uz.anarxiya.radiation;

import org.bukkit.Bukkit;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.plugin.java.JavaPlugin;
import uz.anarxiya.radiation.commands.RadiationCommand;
import uz.anarxiya.radiation.gui.MenuManager;
import uz.anarxiya.radiation.items.CustomItemManager;
import uz.anarxiya.radiation.listeners.CustomItemListener;
import uz.anarxiya.radiation.listeners.MobDeathListener;
import uz.anarxiya.radiation.listeners.WorldEnterListener;
import uz.anarxiya.radiation.managers.*;

import uz.anarxiya.radiation.util.Text;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;

public class RadiationPlugin extends JavaPlugin {

    /** config.yml tuzilmasi o'zgarganda oshiriladi (eski config avtomatik zaxiralanadi) */
    public static final int CONFIG_VERSION = 3;

    private static RadiationPlugin instance;

    private WorldManager worldManager;
    private RadiationManager radiationManager;
    private MobManager mobManager;
    private StructureManager structureManager;
    private LootManager lootManager;
    private SuitManager suitManager;
    private CustomItemManager customItemManager;
    private ConfigManager configManager;
    private GeigerManager geigerManager;
    private AtmosphereManager atmosphereManager;
    private MenuManager menuManager;

    @Override
    public void onEnable() {
        instance = this;
        migrateOldConfig();
        saveDefaultConfig();

        // Manager'larni ishga tushirish
        this.configManager = new ConfigManager(this);
        this.suitManager = new SuitManager(this);
        this.customItemManager = new CustomItemManager(this, suitManager);
        this.lootManager = new LootManager(this, customItemManager);
        this.structureManager = new StructureManager(this, lootManager);
        this.worldManager = new WorldManager(this, structureManager);
        this.radiationManager = new RadiationManager(this, suitManager);
        this.mobManager = new MobManager(this);
        this.geigerManager = new GeigerManager(this);
        this.atmosphereManager = new AtmosphereManager(this);
        this.menuManager = new MenuManager(this);

        // MythicMobs bor bo'lsa, mob fayllarini o'rnatish (fayl allaqachon bo'lsa tegmaydi)
        if (getConfig().getBoolean("mythicmobs.auto-install", true) && mobManager.isMythicConnected()) {
            MobManager.InstallResult result = mobManager.installMythicConfigs(false);
            if (result == MobManager.InstallResult.ALREADY_EXISTS) {
                getLogger().info("MythicMobs/Mobs/RadiationZone.yml allaqachon mavjud (o'zgartirilmadi). "
                        + "Yangilash uchun: /radiation mythic install");
            }
        }

        // Komandalar
        RadiationCommand cmd = new RadiationCommand(this);
        getCommand("radiation").setExecutor(cmd);
        getCommand("radiation").setTabCompleter(cmd);

        // Listenerlar
        Bukkit.getPluginManager().registerEvents(new WorldEnterListener(this), this);
        Bukkit.getPluginManager().registerEvents(new CustomItemListener(this), this);
        Bukkit.getPluginManager().registerEvents(new MobDeathListener(this), this);
        Bukkit.getPluginManager().registerEvents(menuManager, this);

        // Doimiy tekshiruv tasklarini boshlash
        radiationManager.start();
        mobManager.start();
        geigerManager.start();
        atmosphereManager.start();
        worldManager.scheduleAutoReset();

        getLogger().info("RadiationZone plugin yoqildi! world1 nazorat ostida.");
    }

    @Override
    public void onDisable() {
        if (radiationManager != null) radiationManager.stop();
        if (mobManager != null) mobManager.stop();
        if (geigerManager != null) geigerManager.stop();
        if (atmosphereManager != null) atmosphereManager.stop();
        if (structureManager != null) structureManager.cancelTasks();
        if (worldManager != null) worldManager.cancelTasks();
        getLogger().info("RadiationZone plugin o'chirildi.");
    }

    /** Eski versiya config'i bo'lsa, uni zaxiralab, yangisini yaratishga o'rin ochadi */
    private void migrateOldConfig() {
        File configFile = new File(getDataFolder(), "config.yml");
        if (!configFile.exists()) return;

        YamlConfiguration onDisk = YamlConfiguration.loadConfiguration(configFile);
        if (onDisk.getInt("config-version", 1) >= CONFIG_VERSION) return;

        File backup = new File(getDataFolder(), "config-old-" + System.currentTimeMillis() + ".yml");
        try {
            Files.move(configFile.toPath(), backup.toPath(), StandardCopyOption.REPLACE_EXISTING);
            getLogger().warning("Eski config.yml yangi versiyaga o'tkazildi. Eskisi saqlandi: " + backup.getName());
        } catch (IOException e) {
            getLogger().warning("Eski config.yml ni zaxiralab bo'lmadi: " + e.getMessage());
        }
    }

    /** config.yml va barcha qo'shimcha yml fayllarni qayta yuklaydi */
    public void reloadAll() {
        reloadConfig();
        configManager.reload();
    }

    /** messages.yml dan xabar oladi. Almashtirishlar juft-juft: msg("key", "{player}", "Ali") */
    public String msg(String key, String... replacements) {
        String text = configManager.messages().getString(key);
        if (text == null) text = "§c[" + key + "]";
        for (int i = 0; i + 1 < replacements.length; i += 2) {
            text = text.replace(replacements[i], replacements[i + 1]);
        }
        return Text.color(text);
    }

    public static RadiationPlugin get() {
        return instance;
    }

    public WorldManager getWorldManager() { return worldManager; }
    public RadiationManager getRadiationManager() { return radiationManager; }
    public MobManager getMobManager() { return mobManager; }
    public StructureManager getStructureManager() { return structureManager; }
    public LootManager getLootManager() { return lootManager; }
    public SuitManager getSuitManager() { return suitManager; }
    public CustomItemManager getCustomItemManager() { return customItemManager; }
    public ConfigManager getConfigManager() { return configManager; }
    public MenuManager getMenuManager() { return menuManager; }
}
