package uz.anarxiya.radiation.util;

import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffectType;

import java.util.List;
import java.util.Locale;

/** Potion effekt nomlarini versiyaga qaramay to'g'ri topish (NAUSEA/CONFUSION, SLOWNESS/SLOW va h.k.) */
public final class EffectUtil {

    private EffectUtil() {}

    /** Zararli effektlar ro'yxati (tibbiy to'plam va Rad-Away tozalaydi) */
    public static final List<String> NEGATIVE = List.of(
            "NAUSEA", "WEAKNESS", "SLOWNESS", "POISON", "HUNGER", "WITHER", "BLINDNESS", "MINING_FATIGUE");

    public static PotionEffectType resolve(String name) {
        if (name == null || name.isBlank()) return null;
        String n = name.trim();
        PotionEffectType type = PotionEffectType.getByName(n.toUpperCase(Locale.ROOT));
        if (type != null) return type;
        return PotionEffectType.getByKey(NamespacedKey.minecraft(n.toLowerCase(Locale.ROOT)));
    }

    public static void clearNegative(Player player) {
        for (String name : NEGATIVE) {
            PotionEffectType type = resolve(name);
            if (type != null) player.removePotionEffect(type);
        }
    }
}
