package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;

import java.util.List;

public class RadiationManager {

    private final RadiationPlugin plugin;
    private final SuitManager suitManager;
    private BukkitTask task;

    public RadiationManager(RadiationPlugin plugin, SuitManager suitManager) {
        this.plugin = plugin;
        this.suitManager = suitManager;
    }

    public void start() {
        long interval = plugin.getConfig().getLong("radiation.damage-interval-ticks", 40L);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void tick() {
        String worldName = plugin.getConfig().getString("world.name", "world1");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return;

        for (Player player : world.getPlayers()) {
            if (player.hasPermission("radiation.immune") || player.isOp() && player.getGameMode().name().equals("CREATIVE")) {
                continue;
            }

            int ring = getRingAt(player.getLocation().getBlockX(), player.getLocation().getBlockZ());
            if (ring <= 0) continue; // markazda (0-halqadan tashqarida) radiatsiya yo'q hisoblanadi, agar kerak bo'lsa buni o'zgartiring

            boolean protected_ = suitManager.isFullyProtected(player);
            if (protected_) continue;

            applyRadiation(player, ring);
        }
    }

    /** X,Z koordinatalariga qarab qaysi halqada ekanini hisoblaydi (1,2,3,4...) */
    public int getRingAt(int x, int z) {
        int centerX = plugin.getConfig().getInt("world.center-x", 0);
        int centerZ = plugin.getConfig().getInt("world.center-z", 0);
        int ringSize = plugin.getConfig().getInt("radiation.ring-size", 2500);

        double dx = x - centerX;
        double dz = z - centerZ;
        double distance = Math.sqrt(dx * dx + dz * dz);

        int ring = (int) Math.floor(distance / ringSize) + 1;
        return Math.max(ring, 1);
    }

    private void applyRadiation(Player player, int ring) {
        ConfigurationSection dmgSection = plugin.getConfig().getConfigurationSection("radiation.ring-damage");
        double damage = 1.0;
        if (dmgSection != null) {
            damage = dmgSection.getDouble(String.valueOf(Math.min(ring, 4)), 1.0);
        }

        player.damage(damage);

        String warn = plugin.getConfig().getString("radiation.warning-message", "");
        if (!warn.isEmpty()) {
            player.sendActionBar(net.kyori.adventure.text.Component.text(
                    warn.replace("&", "§")));
        }

        List<String> effects = plugin.getConfig().getStringList("radiation.extra-effects-without-suit");
        for (String line : effects) {
            String[] parts = line.split(":");
            if (parts.length < 3) continue;
            try {
                PotionEffectType type = PotionEffectType.getByName(parts[0]);
                if (type == null) continue;
                int amplifier = Integer.parseInt(parts[1]);
                int seconds = Integer.parseInt(parts[2]);
                player.addPotionEffect(new PotionEffect(type, seconds * 20, amplifier, true, false));
            } catch (NumberFormatException ignored) {
            }
        }

        if (player.getHealth() <= damage) {
            String deathMsg = plugin.getConfig().getString("radiation.death-message", "{player} radiatsiyadan nobud bo'ldi!");
            Bukkit.broadcast(net.kyori.adventure.text.Component.text(
                    deathMsg.replace("{player}", player.getName()).replace("&", "§")));
        }
    }
}
