package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.EffectUtil;
import uz.anarxiya.radiation.util.Text;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

public class RadiationManager {

    private final RadiationPlugin plugin;
    private final SuitManager suitManager;
    private final Map<UUID, Long> immuneUntil = new HashMap<>();
    private BukkitTask task;

    public RadiationManager(RadiationPlugin plugin, SuitManager suitManager) {
        this.plugin = plugin;
        this.suitManager = suitManager;
    }

    public void start() {
        long interval = plugin.getConfig().getLong("radiation.damage-interval-ticks", 40L);
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    // ---------- Antirad himoyasi (tabletka / Rad-Away) ----------

    /** O'yinchiga vaqtinchalik radiatsiyadan himoya beradi. Bir necha marta ishlatsa, vaqt qo'shiladi. */
    public void grantImmunity(Player player, int seconds) {
        long now = System.currentTimeMillis();
        long base = Math.max(now, immuneUntil.getOrDefault(player.getUniqueId(), 0L));
        long until = base + seconds * 1000L;
        long cap = now + plugin.getConfig().getLong("radiation.max-immunity-seconds", 900L) * 1000L;
        immuneUntil.put(player.getUniqueId(), Math.min(until, cap));
    }

    /** Qolgan himoya vaqti (soniya), yo'q bo'lsa 0 */
    public long getImmunitySeconds(Player player) {
        Long until = immuneUntil.get(player.getUniqueId());
        if (until == null) return 0;
        return Math.max(0, (until - System.currentTimeMillis() + 999) / 1000);
    }

    private void tick() {
        String worldName = plugin.getConfig().getString("world.name", "world1");
        World world = Bukkit.getWorld(worldName);
        if (world == null) return;

        long now = System.currentTimeMillis();
        immuneUntil.values().removeIf(until -> until <= now);

        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == GameMode.SPECTATOR) continue;
            if (player.hasPermission("radiation.immune") || player.isOp() && player.getGameMode() == GameMode.CREATIVE) {
                continue;
            }

            int ring = getRingAt(player.getLocation().getBlockX(), player.getLocation().getBlockZ());
            if (ring <= 0) continue;

            if (suitManager.isFullyProtected(player)) continue;

            long immune = getImmunitySeconds(player);
            if (immune > 0) {
                player.sendActionBar(Text.component(plugin.msg("antirad-actionbar", "{seconds}", String.valueOf(immune))));
                continue;
            }

            applyRadiation(player, ring);
        }
    }

    /** X,Z koordinatalariga qarab qaysi halqada ekanini hisoblaydi (1,2,3,4...) */
    public int getRingAt(int x, int z) {
        int centerX = plugin.getConfig().getInt("world.center-x", 0);
        int centerZ = plugin.getConfig().getInt("world.center-z", 0);
        int ringSize = plugin.getConfig().getInt("radiation.ring-size", 2500);

        double dx = x - centerX;
        double dz = z - centerZ;
        double distance = Math.sqrt(dx * dx + dz * dz);

        int ring = (int) Math.floor(distance / ringSize) + 1;
        return Math.max(ring, 1);
    }

    private void applyRadiation(Player player, int ring) {
        ConfigurationSection dmgSection = plugin.getConfig().getConfigurationSection("radiation.ring-damage");
        double damage = 1.0;
        if (dmgSection != null) {
            damage = dmgSection.getDouble(String.valueOf(Math.min(ring, 4)), 1.0);
        }

        // o'lim xabari uchun zarar berishdan OLDIN tekshiramiz
        boolean willDie = player.getHealth() <= damage;

        player.damage(damage);

        String warn = plugin.msg("radiation-warning");
        if (!warn.isEmpty()) {
            player.sendActionBar(Text.component(warn));
        }

        List<String> effects = plugin.getConfig().getStringList("radiation.extra-effects-without-suit");
        for (String line : effects) {
            String[] parts = line.split(":");
            if (parts.length < 3) continue;
            try {
                PotionEffectType type = EffectUtil.resolve(parts[0]);
                if (type == null) continue;
                int amplifier = Integer.parseInt(parts[1].trim());
                int seconds = Integer.parseInt(parts[2].trim());
                player.addPotionEffect(new PotionEffect(type, seconds * 20, amplifier, true, false));
            } catch (NumberFormatException ignored) {
            }
        }

        if (willDie) {
            Bukkit.broadcast(Text.component(plugin.msg("radiation-death", "{player}", player.getName())));
        }
    }
}
