package uz.anarxiya.radiation.managers;

import org.bukkit.Color;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.LeatherArmorMeta;
import org.bukkit.persistence.PersistentDataType;
import uz.anarxiya.radiation.RadiationPlugin;

public class SuitManager {

    private final RadiationPlugin plugin;
    private final NamespacedKey suitKey;

    public SuitManager(RadiationPlugin plugin) {
        this.plugin = plugin;
        this.suitKey = new NamespacedKey(plugin, "radiation_suit_part");
    }

    /** Bitta kostyum qismini (helmet/chestplate/leggings/boots) yasaydi */
    public ItemStack createSuitPart(String part) {
        String matPath = "suit.material." + part;
        Material mat = Material.matchMaterial(plugin.getConfig().getString(matPath, "LEATHER_HELMET"));
        if (mat == null) mat = Material.LEATHER_HELMET;

        ItemStack item = new ItemStack(mat);
        LeatherArmorMeta meta = (LeatherArmorMeta) item.getItemMeta();

        meta.setDisplayName(plugin.getConfig().getString("suit.name", "&aRadiatsiyaga qarshi kostyum")
                .replace("&", "§"));

        int cmd = plugin.getConfig().getInt("suit.custom-model-data", 100001);
        meta.setCustomModelData(cmd);

        var colorList = plugin.getConfig().getIntegerList("suit.color");
        if (colorList.size() == 3) {
            meta.setColor(Color.fromRGB(colorList.get(0), colorList.get(1), colorList.get(2)));
        }

        meta.getPersistentDataContainer().set(suitKey, PersistentDataType.STRING, part);
        item.setItemMeta(meta);
        return item;
    }

    /** O'yinchiga to'liq kostyum beradi */
    public void giveFullSuit(Player player) {
        player.getInventory().setHelmet(createSuitPart("helmet"));
        player.getInventory().setChestplate(createSuitPart("chestplate"));
        player.getInventory().setLeggings(createSuitPart("leggings"));
        player.getInventory().setBoots(createSuitPart("boots"));
    }

    /** O'yinchi to'liq himoyalangan kostyum kiyganmi, tekshiradi */
    public boolean isFullyProtected(Player player) {
        boolean requireFull = plugin.getConfig().getBoolean("suit.require-full-set", true);

        boolean helmet = isSuitPart(player.getInventory().getHelmet(), "helmet");
        boolean chest = isSuitPart(player.getInventory().getChestplate(), "chestplate");
        boolean legs = isSuitPart(player.getInventory().getLeggings(), "leggings");
        boolean boots = isSuitPart(player.getInventory().getBoots(), "boots");

        if (requireFull) {
            return helmet && chest && legs && boots;
        }
        // agar to'liq kiyim shart bo'lmasa, kamida ko'krak qismi yetarli
        return chest;
    }

    /** Buyum kostyum qismi bo'lsa "helmet"/"chestplate"/... qaytaradi, aks holda null */
    public String getPartName(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(suitKey, PersistentDataType.STRING);
    }

    private boolean isSuitPart(ItemStack item, String expectedPart) {
        if (item == null || !item.hasItemMeta()) return false;
        String val = item.getItemMeta().getPersistentDataContainer()
                .get(suitKey, PersistentDataType.STRING);
        return expectedPart.equals(val);
    }
}
