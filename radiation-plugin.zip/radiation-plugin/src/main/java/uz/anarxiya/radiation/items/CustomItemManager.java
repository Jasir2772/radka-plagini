package uz.anarxiya.radiation.items;

import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.managers.SuitManager;
import uz.anarxiya.radiation.util.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

/** items.yml dan maxsus buyumlar (antirad tabletka, tibbiy to'plam va h.k.) yasaydi */
public class CustomItemManager {

    private static final Set<String> SUIT_PARTS = Set.of("helmet", "chestplate", "leggings", "boots");

    private final RadiationPlugin plugin;
    private final SuitManager suitManager;
    private final NamespacedKey idKey;

    public CustomItemManager(RadiationPlugin plugin, SuitManager suitManager) {
        this.plugin = plugin;
        this.suitManager = suitManager;
        this.idKey = new NamespacedKey(plugin, "custom_item");
    }

    /** id bo'yicha buyum yasaydi. id topilmasa null. "suit_helmet" kabi id'lar kostyum qismini beradi. */
    public ItemStack create(String id, int amount) {
        if (id == null) return null;

        if (id.startsWith("suit_")) {
            String part = id.substring(5);
            return SUIT_PARTS.contains(part) ? suitManager.createSuitPart(part) : null;
        }

        ConfigurationSection section = getSection(id);
        if (section == null) return null;

        Material mat = Material.matchMaterial(section.getString("material", "PAPER"));
        if (mat == null || mat.isAir()) mat = Material.PAPER;

        ItemStack item = new ItemStack(mat, Math.max(1, Math.min(amount, mat.getMaxStackSize())));
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return item;

        meta.setDisplayName(Text.color(section.getString("name", id)));

        List<String> lore = section.getStringList("lore");
        if (!lore.isEmpty()) meta.setLore(Text.color(lore));

        if (section.contains("custom-model-data")) {
            meta.setCustomModelData(section.getInt("custom-model-data"));
        }

        meta.getPersistentDataContainer().set(idKey, PersistentDataType.STRING, id);
        item.setItemMeta(meta);
        return item;
    }

    /** Buyum bizning maxsus buyumimi bo'lsa, uning id'sini qaytaradi, aks holda null */
    public String getId(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return null;
        return item.getItemMeta().getPersistentDataContainer().get(idKey, PersistentDataType.STRING);
    }

    public ConfigurationSection getSection(String id) {
        return plugin.getConfigManager().items().getConfigurationSection(id);
    }

    /** Barcha mavjud id'lar (tab-complete uchun) */
    public List<String> ids() {
        List<String> ids = new ArrayList<>();
        ids.addAll(plugin.getConfigManager().items().getKeys(false));
        for (String part : List.of("helmet", "chestplate", "leggings", "boots")) ids.add("suit_" + part);
        return ids;
    }
}
