package uz.anarxiya.radiation.managers;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockState;
import org.bukkit.block.Container;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.items.CustomItemManager;
import uz.anarxiya.radiation.util.Text;

import java.util.*;

/**
 * Sandiq/bochka loot'i.
 * Loot = shu joy ringi jadvali (chests.loot.ring-N) + struktura turi jadvali (chests.structure-loot.TUR)
 */
public class LootManager {

    private final RadiationPlugin plugin;
    private final CustomItemManager customItems;
    private final Random random = new Random();
    private final Set<String> warned = new HashSet<>();

    public LootManager(RadiationPlugin plugin, CustomItemManager customItems) {
        this.plugin = plugin;
        this.customItems = customItems;
    }

    /** Berilgan joydagi sandiq/bochkani loot bilan to'ldiradi. structureTag null bo'lishi mumkin. */
    public boolean fillContainer(Location location, String structureTag) {
        Block block = location.getBlock();
        if (!(block.getState() instanceof Container container)) return false;

        int ring = Math.min(plugin.getRadiationManager().getRingAt(block.getX(), block.getZ()), 4);
        List<ItemStack> loot = rollLoot(ring, structureTag);

        Inventory inventory = container.getInventory();
        inventory.clear();

        List<Integer> slots = new ArrayList<>();
        for (int i = 0; i < inventory.getSize(); i++) slots.add(i);
        Collections.shuffle(slots, random);

        int index = 0;
        for (ItemStack item : loot) {
            if (index >= slots.size()) break;
            inventory.setItem(slots.get(index++), item);
        }
        return true;
    }

    /** Region ichidagi barcha sandiq/bochkalarni to'ldiradi (sxematik struktura joylanganidan keyin) */
    public int fillContainersInRegion(World world, int minX, int minY, int minZ,
                                      int maxX, int maxY, int maxZ, String structureTag) {
        int filled = 0;
        for (int chunkX = minX >> 4; chunkX <= maxX >> 4; chunkX++) {
            for (int chunkZ = minZ >> 4; chunkZ <= maxZ >> 4; chunkZ++) {
                for (BlockState state : world.getChunkAt(chunkX, chunkZ).getTileEntities()) {
                    if (!(state instanceof Container)) continue;
                    if (state.getX() < minX || state.getX() > maxX) continue;
                    if (state.getY() < minY || state.getY() > maxY) continue;
                    if (state.getZ() < minZ || state.getZ() > maxZ) continue;
                    if (fillContainer(state.getLocation(), structureTag)) filled++;
                }
            }
        }
        return filled;
    }

    /** Ring va struktura turiga qarab tasodifiy buyumlar ro'yxatini tuzadi */
    public List<ItemStack> rollLoot(int ring, String structureTag) {
        List<Map<?, ?>> pool = new ArrayList<>(plugin.getConfig().getMapList("chests.loot.ring-" + ring));
        if (structureTag != null) {
            pool.addAll(plugin.getConfig().getMapList("chests.structure-loot." + structureTag));
        }

        List<ItemStack> result = new ArrayList<>();
        if (pool.isEmpty()) return result;

        int maxItems = plugin.getConfig().getInt("chests.max-items", 14);
        int minItems = plugin.getConfig().getInt("chests.min-items", 3);

        // Aralashtiramiz, shunda max-items chegarasi doim bir xil yozuvlarni kesib tashlamaydi
        List<Map<?, ?>> shuffled = new ArrayList<>(pool);
        Collections.shuffle(shuffled, random);

        for (Map<?, ?> entry : shuffled) {
            if (result.size() >= maxItems) break;
            double chance = toDouble(entry.get("chance"), 0.5);
            if (random.nextDouble() > chance) continue;
            ItemStack item = buildItem(entry);
            if (item != null) result.add(item);
        }

        // Sandiq deyarli bo'sh qolmasligi uchun: faqat oddiy (ehtimoli >= 0.3) yozuvlardan to'ldiramiz
        if (result.size() < minItems) {
            List<Map<?, ?>> common = new ArrayList<>();
            for (Map<?, ?> entry : pool) {
                if (toDouble(entry.get("chance"), 0.5) >= 0.3) common.add(entry);
            }
            if (common.isEmpty()) common = pool;

            int guard = 0;
            while (result.size() < minItems && guard++ < 30) {
                ItemStack item = buildItem(common.get(random.nextInt(common.size())));
                if (item != null) result.add(item);
            }
        }
        return result;
    }

    private ItemStack buildItem(Map<?, ?> entry) {
        int min = (int) toDouble(entry.get("min"), 1);
        int max = (int) toDouble(entry.get("max"), min);
        int amount = min + (max > min ? random.nextInt(max - min + 1) : 0);
        amount = Math.max(1, amount);

        ItemStack item;
        Object custom = entry.get("custom");
        if (custom != null) {
            item = customItems.create(String.valueOf(custom), amount);
            if (item == null) {
                warnOnce("Noma'lum maxsus buyum (custom): " + custom);
                return null;
            }
        } else {
            Material material = Material.matchMaterial(String.valueOf(entry.get("item")));
            if (material == null || material.isAir()) {
                warnOnce("Noma'lum material (item): " + entry.get("item"));
                return null;
            }
            item = new ItemStack(material, Math.min(amount, material.getMaxStackSize()));
        }

        applyExtras(item, entry);
        return item;
    }

    /** name / lore / enchants / custom-model-data */
    private void applyExtras(ItemStack item, Map<?, ?> entry) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        Object name = entry.get("name");
        if (name != null) meta.setDisplayName(Text.color(String.valueOf(name)));

        Object lore = entry.get("lore");
        if (lore instanceof List<?> lines) {
            List<String> colored = new ArrayList<>();
            for (Object line : lines) colored.add(Text.color(String.valueOf(line)));
            meta.setLore(colored);
        }

        Object cmd = entry.get("custom-model-data");
        if (cmd instanceof Number number) meta.setCustomModelData(number.intValue());

        Object enchants = entry.get("enchants");
        if (enchants instanceof List<?> list) {
            for (Object o : list) {
                String[] parts = String.valueOf(o).split(":");
                Enchantment enchantment = Enchantment.getByKey(
                        NamespacedKey.minecraft(parts[0].trim().toLowerCase(Locale.ROOT)));
                if (enchantment == null) {
                    warnOnce("Noma'lum enchant: " + parts[0]);
                    continue;
                }
                int level = 1;
                if (parts.length > 1) {
                    try {
                        level = Integer.parseInt(parts[1].trim());
                    } catch (NumberFormatException ignored) {
                    }
                }
                meta.addEnchant(enchantment, level, true);
            }
        }
        item.setItemMeta(meta);
    }

    private void warnOnce(String message) {
        if (warned.add(message)) plugin.getLogger().warning("[Loot] " + message);
    }

    private double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return def;
        }
    }
}
