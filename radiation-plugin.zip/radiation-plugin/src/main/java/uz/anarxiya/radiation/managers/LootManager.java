package uz.anarxiya.radiation.managers;

import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.Chest;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.inventory.ItemStack;
import uz.anarxiya.radiation.RadiationPlugin;

import java.util.*;

public class LootManager {

    private final RadiationPlugin plugin;
    private final Random random = new Random();

    public LootManager(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    /** Berilgan joydagi sandiqni shu joyning ringiga mos loot bilan to'ldiradi */
    public void fillChestForLocation(Location chestLocation) {
        Block block = chestLocation.getBlock();
        if (block.getType() != Material.CHEST && block.getType() != Material.TRAPPED_CHEST) return;

        int ring = Math.min(plugin.getRadiationManager()
                .getRingAt(chestLocation.getBlockX(), chestLocation.getBlockZ()), 4);

        List<Map<?, ?>> lootTable = plugin.getConfig().getMapList("chests.loot.ring-" + ring);
        if (lootTable.isEmpty()) return;

        Chest chest = (Chest) block.getState();
        chest.getBlockInventory().clear();

        List<Integer> slots = availableSlots(chest.getBlockInventory().getSize());
        Collections.shuffle(slots, random);
        int slotIndex = 0;

        for (Map<?, ?> entry : lootTable) {
            double chance = toDouble(entry.get("chance"), 0.5);
            if (random.nextDouble() > chance) continue;
            if (slotIndex >= slots.size()) break;

            String matName = String.valueOf(entry.get("item"));
            Material mat = Material.matchMaterial(matName);
            if (mat == null) continue;

            int min = (int) toDouble(entry.get("min"), 1);
            int max = (int) toDouble(entry.get("max"), 1);
            int amount = min + (max > min ? random.nextInt(max - min + 1) : 0);

            chest.getBlockInventory().setItem(slots.get(slotIndex), new ItemStack(mat, amount));
            slotIndex++;
        }
    }

    /** Berilgan region ichidagi barcha sandiqlarni topib to'ldiradi (struktura joylashtirilgandan keyin chaqiriladi) */
    public void fillChestsInRegion(org.bukkit.World world, int minX, int minY, int minZ, int maxX, int maxY, int maxZ) {
        for (int x = minX; x <= maxX; x++) {
            for (int y = minY; y <= maxY; y++) {
                for (int z = minZ; z <= maxZ; z++) {
                    Block b = world.getBlockAt(x, y, z);
                    if (b.getType() == Material.CHEST || b.getType() == Material.TRAPPED_CHEST) {
                        fillChestForLocation(b.getLocation());
                    }
                }
            }
        }
    }

    private List<Integer> availableSlots(int size) {
        List<Integer> list = new ArrayList<>();
        for (int i = 0; i < size; i++) list.add(i);
        return list;
    }

    private double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return def;
        }
    }
}
