package uz.anarxiya.radiation.managers;

import org.bukkit.configuration.file.YamlConfiguration;
import uz.anarxiya.radiation.RadiationPlugin;

import java.io.File;
import java.io.IOException;

/** loot.yml, mobs.yml, items.yml, messages.yml fayllarini yuklaydi va (menyu o'zgartirsa) saqlaydi */
public class ConfigManager {

    private final RadiationPlugin plugin;
    private YamlConfiguration loot;
    private YamlConfiguration mobs;
    private YamlConfiguration items;
    private YamlConfiguration messages;

    public ConfigManager(RadiationPlugin plugin) {
        this.plugin = plugin;
        reload();
    }

    public void reload() {
        loot = load("loot.yml");
        mobs = load("mobs.yml");
        items = load("items.yml");
        messages = load("messages.yml");
    }

    private YamlConfiguration load(String name) {
        File file = new File(plugin.getDataFolder(), name);
        if (!file.exists()) plugin.saveResource(name, false);
        return YamlConfiguration.loadConfiguration(file);
    }

    private void save(YamlConfiguration yaml, String name) {
        try {
            yaml.save(new File(plugin.getDataFolder(), name));
        } catch (IOException e) {
            plugin.getLogger().warning(name + " ni saqlab bo'lmadi: " + e.getMessage());
        }
    }

    public YamlConfiguration loot() { return loot; }
    public YamlConfiguration mobs() { return mobs; }
    public YamlConfiguration items() { return items; }
    public YamlConfiguration messages() { return messages; }

    public void saveLoot() { save(loot, "loot.yml"); }
    public void saveMobs() { save(mobs, "mobs.yml"); }
}
