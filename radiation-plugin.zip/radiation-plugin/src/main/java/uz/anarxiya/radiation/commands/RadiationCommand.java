package uz.anarxiya.radiation.commands;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.managers.MobManager;
import uz.anarxiya.radiation.managers.StructureManager;
import uz.anarxiya.radiation.structures.ProceduralBuilder;
import uz.anarxiya.radiation.util.Text;

import java.util.*;

public class RadiationCommand implements CommandExecutor, TabCompleter {

    private static final List<String> SUBS = List.of(
            "reload", "reset", "info", "givesuit", "giveitem", "structures", "spawnmob", "fillchest", "mythic");

    private final RadiationPlugin plugin;

    public RadiationCommand(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("radiation.admin")) {
            sender.sendMessage(Text.color(plugin.getConfig().getString("messages.no-permission", "§cRuxsat yo'q!")));
            return true;
        }

        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        switch (args[0].toLowerCase(Locale.ROOT)) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage("§aConfig qayta yuklandi!");
            }
            case "reset" -> {
                sender.sendMessage("§cworld1 darhol reset qilinmoqda...");
                plugin.getWorldManager().resetWorld();
            }
            case "info" -> {
                long seconds = plugin.getWorldManager().getSecondsUntilReset();
                sender.sendMessage("§eKeyingi resetgacha: §f" + (seconds / 3600) + "s " + ((seconds % 3600) / 60) + "m");
                sender.sendMessage("§eJoylashgan strukturalar: §f" + plugin.getStructureManager().getPlaced().size()
                        + (plugin.getStructureManager().isBusy() ? " §7(qurilmoqda...)" : ""));
                sender.sendMessage("§eMythicMobs: " + (plugin.getMobManager().isMythicConnected() ? "§aulangan" : "§cyo'q (vanilla fallback)"));
            }
            case "givesuit" -> giveSuit(sender, args);
            case "giveitem" -> giveItem(sender, args);
            case "structures" -> structures(sender, args);
            case "spawnmob" -> spawnMob(sender, args);
            case "fillchest" -> fillChest(sender, args);
            case "mythic" -> mythic(sender, args);
            default -> sender.sendMessage("§cNoma'lum komanda. /radiation - yordam uchun");
        }
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§e/radiation reload §7- config'ni qayta yuklash");
        sender.sendMessage("§e/radiation reset §7- world1'ni darhol reset qilish");
        sender.sendMessage("§e/radiation info §7- resetgacha vaqt, strukturalar, MythicMobs holati");
        sender.sendMessage("§e/radiation givesuit <player> §7- radiatsiya kostyumi berish");
        sender.sendMessage("§e/radiation giveitem <id> [player] [soni] §7- maxsus buyum (antirad_pill, medkit, rad_away, suit_*)");
        sender.sendMessage("§e/radiation structures <generate|list> §7- strukturalar qo'shish / ro'yxat");
        sender.sendMessage("§e/radiation spawnmob <id> §7- sinov uchun mob chaqirish");
        sender.sendMessage("§e/radiation fillchest [struktura_turi] §7- qarab turgan sandiqni loot bilan to'ldirish");
        sender.sendMessage("§e/radiation mythic <status|install> §7- MythicMobs ulanishini tekshirish / mob faylini o'rnatish");
    }

    private void giveSuit(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cFoydalanish: /radiation givesuit <player>");
            return;
        }
        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage("§cO'yinchi topilmadi!");
            return;
        }
        plugin.getSuitManager().giveFullSuit(target);
        sender.sendMessage("§aRadiatsiya kostyumi " + target.getName() + "ga berildi.");
    }

    private void giveItem(CommandSender sender, String[] args) {
        if (args.length < 2) {
            sender.sendMessage("§cFoydalanish: /radiation giveitem <id> [player] [soni]");
            sender.sendMessage("§7Mavjud: " + String.join(", ", plugin.getCustomItemManager().ids()));
            return;
        }
        Player target = null;
        if (args.length >= 3) target = Bukkit.getPlayer(args[2]);
        else if (sender instanceof Player p) target = p;
        if (target == null) {
            sender.sendMessage("§cO'yinchi topilmadi!");
            return;
        }
        int amount = 1;
        if (args.length >= 4) {
            try {
                amount = Math.max(1, Math.min(64, Integer.parseInt(args[3])));
            } catch (NumberFormatException ignored) {
            }
        }
        ItemStack item = plugin.getCustomItemManager().create(args[1], amount);
        if (item == null) {
            sender.sendMessage("§cBunday maxsus buyum yo'q: " + args[1]);
            return;
        }
        Map<Integer, ItemStack> leftover = target.getInventory().addItem(item);
        for (ItemStack rest : leftover.values()) {
            target.getWorld().dropItemNaturally(target.getLocation(), rest);
        }
        sender.sendMessage("§a" + target.getName() + "ga berildi: §f" + args[1] + " x" + amount);
    }

    private void structures(CommandSender sender, String[] args) {
        StructureManager sm = plugin.getStructureManager();
        String sub = args.length >= 2 ? args[1].toLowerCase(Locale.ROOT) : "list";

        if (sub.equals("generate")) {
            World world = Bukkit.getWorld(plugin.getConfig().getString("world.name", "world1"));
            if (world == null) {
                sender.sendMessage("§cRadiatsiya dunyosi topilmadi (world.name ni tekshiring).");
                return;
            }
            if (sm.isBusy()) {
                sender.sendMessage("§eStrukturalar allaqachon qurilmoqda, kuting.");
                return;
            }
            sender.sendMessage("§aYangi strukturalar asta-sekin joylashtirilmoqda (konsol/logda natija chiqadi)...");
            sm.generate(world);
        } else {
            Map<String, Integer> counts = new TreeMap<>();
            for (StructureManager.PlacedStructure s : sm.getPlaced()) counts.merge(s.type(), 1, Integer::sum);
            sender.sendMessage("§eJami strukturalar: §f" + sm.getPlaced().size() + " §7" + counts);
            sender.sendMessage("§7Protsedura turlari: " + String.join(", ", ProceduralBuilder.TYPES));
            sender.sendMessage("§7Sxematik (WorldEdit) qo'llab-quvvatlash: " + (sm.hasSchematicSupport() ? "§aha" : "§cyo'q"));
        }
    }

    private void spawnMob(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cBu komandani faqat o'yinchi ishlatishi mumkin.");
            return;
        }
        if (args.length < 2) {
            sender.sendMessage("§cFoydalanish: /radiation spawnmob <id>");
            return;
        }
        Map<?, ?> data = plugin.getMobManager().findMobData(args[1]);
        if (data == null) {
            sender.sendMessage("§cconfig.yml'da bunday mob id yo'q: " + args[1]);
            return;
        }
        Location loc = player.getLocation().add(player.getLocation().getDirection().setY(0).normalize().multiply(3));
        LivingEntity mob = plugin.getMobManager().spawnEntry(loc, data, false);
        sender.sendMessage(mob != null
                ? "§aMob chaqirildi: §f" + args[1] + " §7(" + mob.getType() + ")"
                : "§cMobni chaqirib bo'lmadi.");
    }

    private void fillChest(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cBu komandani faqat o'yinchi ishlatishi mumkin.");
            return;
        }
        Block target = player.getTargetBlockExact(6);
        if (target == null) {
            sender.sendMessage("§cSandiq yoki bochkaga qarab turing (6 blok ichida).");
            return;
        }
        String tag = args.length >= 2 ? args[1] : null;
        boolean ok = plugin.getLootManager().fillContainer(target.getLocation(), tag);
        sender.sendMessage(ok ? "§aLoot solindi." + (tag != null ? " §7(tur: " + tag + ")" : "")
                : "§cBu blok sandiq/bochka emas.");
    }

    private void mythic(CommandSender sender, String[] args) {
        String sub = args.length >= 2 ? args[1].toLowerCase(Locale.ROOT) : "status";
        MobManager mm = plugin.getMobManager();

        if (sub.equals("install")) {
            switch (mm.installMythicConfigs(true)) {
                case INSTALLED -> sender.sendMessage("§aMob fayli o'rnatildi: plugins/MythicMobs/Mobs/RadiationZone.yml. "
                        + "MythicMobs qayta yuklanmoqda (mm reload)...");
                case NO_MYTHICMOBS -> sender.sendMessage("§cMythicMobs serverda o'rnatilmagan.");
                case ALREADY_EXISTS -> sender.sendMessage("§eFayl allaqachon mavjud.");
                case ERROR -> sender.sendMessage("§cO'rnatishda xatolik, konsol logini ko'ring.");
            }
        } else {
            mm.sendMythicStatus(sender);
        }
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> options = new ArrayList<>();
        if (args.length == 1) {
            options.addAll(SUBS);
        } else if (args.length == 2) {
            switch (args[0].toLowerCase(Locale.ROOT)) {
                case "givesuit" -> Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
                case "giveitem" -> options.addAll(plugin.getCustomItemManager().ids());
                case "structures" -> options.addAll(List.of("generate", "list"));
                case "spawnmob" -> options.addAll(plugin.getMobManager().allMobIds());
                case "fillchest" -> options.addAll(ProceduralBuilder.TYPES);
                case "mythic" -> options.addAll(List.of("status", "install"));
                default -> { }
            }
        } else if (args.length == 3 && args[0].equalsIgnoreCase("giveitem")) {
            Bukkit.getOnlinePlayers().forEach(p -> options.add(p.getName()));
        }

        String current = args[args.length - 1].toLowerCase(Locale.ROOT);
        options.removeIf(o -> !o.toLowerCase(Locale.ROOT).startsWith(current));
        return options;
    }
}
