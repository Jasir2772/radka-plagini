package uz.anarxiya.radiation.commands;

import org.bukkit.Bukkit;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.managers.SuitManager;
import uz.anarxiya.radiation.managers.WorldManager;

import java.util.ArrayList;
import java.util.List;

public class RadiationCommand implements CommandExecutor, TabCompleter {

    private final RadiationPlugin plugin;
    private final WorldManager worldManager;
    private final SuitManager suitManager;

    public RadiationCommand(RadiationPlugin plugin, WorldManager worldManager, SuitManager suitManager) {
        this.plugin = plugin;
        this.worldManager = worldManager;
        this.suitManager = suitManager;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("radiation.admin")) {
            sender.sendMessage(plugin.getConfig().getString("messages.no-permission", "§cRuxsat yo'q!").replace("&", "§"));
            return true;
        }

        if (args.length == 0) {
            sender.sendMessage("§e/radiation reload §7- config'ni qayta yuklash");
            sender.sendMessage("§e/radiation reset §7- world1'ni darhol reset qilish");
            sender.sendMessage("§e/radiation info §7- keyingi resetgacha qolgan vaqt");
            sender.sendMessage("§e/radiation givesuit <player> §7- radiatsiya kostyumi berish");
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "reload" -> {
                plugin.reloadConfig();
                sender.sendMessage("§aConfig qayta yuklandi!");
            }
            case "reset" -> {
                sender.sendMessage("§cworld1 darhol reset qilinmoqda...");
                worldManager.resetWorld();
            }
            case "info" -> {
                long seconds = worldManager.getSecondsUntilReset();
                long h = seconds / 3600;
                long m = (seconds % 3600) / 60;
                sender.sendMessage("§eKeyingi resetgacha: §f" + h + "s " + m + "m");
            }
            case "givesuit" -> {
                if (args.length < 2) {
                    sender.sendMessage("§cFoydalanish: /radiation givesuit <player>");
                    return true;
                }
                Player target = Bukkit.getPlayer(args[1]);
                if (target == null) {
                    sender.sendMessage("§cO'yinchi topilmadi!");
                    return true;
                }
                suitManager.giveFullSuit(target);
                sender.sendMessage("§aRadiatsiya kostyumi " + target.getName() + "ga berildi.");
            }
            default -> sender.sendMessage("§cNoma'lum komanda. /radiation - yordam uchun");
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> result = new ArrayList<>();
        if (args.length == 1) {
            for (String sub : List.of("reload", "reset", "info", "givesuit")) {
                if (sub.startsWith(args[0].toLowerCase())) result.add(sub);
            }
        } else if (args.length == 2 && args[0].equalsIgnoreCase("givesuit")) {
            for (Player p : Bukkit.getOnlinePlayers()) {
                if (p.getName().toLowerCase().startsWith(args[1].toLowerCase())) result.add(p.getName());
            }
        }
        return result;
    }
}
