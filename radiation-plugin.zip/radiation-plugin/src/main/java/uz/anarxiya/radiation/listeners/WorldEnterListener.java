package uz.anarxiya.radiation.listeners;

import net.kyori.adventure.text.Component;
import net.kyori.adventure.title.Title;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import uz.anarxiya.radiation.RadiationPlugin;

import java.time.Duration;

public class WorldEnterListener implements Listener {

    private final RadiationPlugin plugin;

    public WorldEnterListener(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        checkAndWarn(event.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getTo() == null || event.getFrom().getWorld() == event.getTo().getWorld()) return;
        checkAndWarn(event.getPlayer(), event.getTo().getWorld().getName());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        checkAndWarn(event.getPlayer(), event.getRespawnLocation().getWorld().getName());
    }

    private void checkAndWarn(org.bukkit.entity.Player player) {
        checkAndWarn(player, player.getWorld().getName());
    }

    private void checkAndWarn(org.bukkit.entity.Player player, String worldName) {
        String radiationWorld = plugin.getConfig().getString("world.name", "world1");
        if (!worldName.equalsIgnoreCase(radiationWorld)) return;

        boolean protected_ = plugin.getSuitManager().isFullyProtected(player);

        Title title;
        if (protected_) {
            title = Title.title(
                    Component.text("§a☢ RADIATSIYA ZONASI"),
                    Component.text("§7Siz himoyalangansiz, ehtiyot bo'ling"),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))
            );
        } else {
            title = Title.title(
                    Component.text("§4☢ XAVFLI HUDUD!"),
                    Component.text("§cMaxsus kostyumisiz jon ketishi mumkin!"),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofMillis(500))
            );
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BELL_USE, 1f, 0.5f);
        }

        player.showTitle(title);
        player.sendMessage(plugin.getConfig().getString("messages.prefix", "")
                .replace("&", "§") + (protected_
                ? "§aSiz radiatsiyaga qarshi kostyum kiygansiz."
                : "§c☢ Ogohlantirish: maxsus radiatsiya kostyumisiz bu dunyoda tirik qololmaysiz!"));
    }
}
