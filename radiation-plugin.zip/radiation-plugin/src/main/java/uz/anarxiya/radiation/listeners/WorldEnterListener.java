package uz.anarxiya.radiation.listeners;

import net.kyori.adventure.title.Title;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.player.PlayerChangedWorldEvent;
import org.bukkit.event.player.PlayerRespawnEvent;
import org.bukkit.event.player.PlayerTeleportEvent;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.Text;

import java.time.Duration;

public class WorldEnterListener implements Listener {

    private final RadiationPlugin plugin;

    public WorldEnterListener(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onWorldChange(PlayerChangedWorldEvent event) {
        checkAndWarn(event.getPlayer());
    }

    @EventHandler
    public void onTeleport(PlayerTeleportEvent event) {
        if (event.getTo() == null || event.getFrom().getWorld() == event.getTo().getWorld()) return;
        checkAndWarn(event.getPlayer(), event.getTo().getWorld().getName());
    }

    @EventHandler
    public void onRespawn(PlayerRespawnEvent event) {
        checkAndWarn(event.getPlayer(), event.getRespawnLocation().getWorld().getName());
    }

    private void checkAndWarn(org.bukkit.entity.Player player) {
        checkAndWarn(player, player.getWorld().getName());
    }

    private void checkAndWarn(org.bukkit.entity.Player player, String worldName) {
        String radiationWorld = plugin.getConfig().getString("world.name", "world1");
        if (!worldName.equalsIgnoreCase(radiationWorld)) return;

        boolean protected_ = plugin.getSuitManager().isFullyProtected(player);

        Title title;
        if (protected_) {
            title = Title.title(
                    Text.component(plugin.msg("enter-title-protected")),
                    Text.component(plugin.msg("enter-subtitle-protected")),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(3), Duration.ofMillis(500))
            );
        } else {
            title = Title.title(
                    Text.component(plugin.msg("enter-title-danger")),
                    Text.component(plugin.msg("enter-subtitle-danger")),
                    Title.Times.times(Duration.ofMillis(500), Duration.ofSeconds(4), Duration.ofMillis(500))
            );
            player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_BELL_USE, 1f, 0.5f);
        }

        player.showTitle(title);
        player.sendMessage(plugin.msg("prefix") + plugin.msg(protected_ ? "enter-chat-protected" : "enter-chat-danger"));
    }
}
