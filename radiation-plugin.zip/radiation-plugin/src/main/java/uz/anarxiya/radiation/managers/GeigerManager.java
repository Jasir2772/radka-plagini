package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.Location;
import org.bukkit.SoundCategory;
import org.bukkit.World;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.Text;

import java.util.List;
import java.util.Locale;
import java.util.Random;

/**
 * Geiger schyotchigi ovozi: radiatsiya qancha kuchli bo'lsa, chertishlar shuncha tez.
 * Chertishlar tasodifiy (Puasson taqsimoti) - haqiqiy schyotchikdagidek.
 */
public class GeigerManager {

    private final RadiationPlugin plugin;
    private final Random random = new Random();
    private BukkitTask task;
    private int readoutCounter = 0;

    public GeigerManager(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long interval = Math.max(1L, plugin.getConfig().getLong("sounds.geiger.tick-interval", 2L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::tick, 100L, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void tick() {
        ConfigurationSection cfg = plugin.getConfig().getConfigurationSection("sounds.geiger");
        if (cfg == null || !cfg.getBoolean("enabled", true)) return;

        World world = Bukkit.getWorld(plugin.getConfig().getString("world.name", "world1"));
        if (world == null) return;

        long interval = Math.max(1L, cfg.getLong("tick-interval", 2L));
        boolean itemMode = cfg.getString("mode", "ALWAYS").equalsIgnoreCase("ITEM");
        String deviceId = cfg.getString("device-item", "geiger_counter");
        boolean readout = cfg.getBoolean("readout", true);
        boolean showReadout = readout && (++readoutCounter % 5 == 0);

        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == GameMode.SPECTATOR) continue;

            boolean holding = isDevice(player.getInventory().getItemInMainHand(), deviceId)
                    || isDevice(player.getInventory().getItemInOffHand(), deviceId);
            if (itemMode && !holding && !carries(player, deviceId)) continue;

            Location loc = player.getLocation();
            double ringSize = Math.max(1, plugin.getConfig().getInt("radiation.ring-size", 2500));
            double dx = loc.getX() - plugin.getConfig().getInt("world.center-x", 0);
            double dz = loc.getZ() - plugin.getConfig().getInt("world.center-z", 0);
            double level = Math.sqrt(dx * dx + dz * dz) / ringSize; // 0 = markaz, 1 = 1-halqa oxiri...

            double cps = cfg.getDouble("base-clicks-per-second", 1.0)
                    + level * cfg.getDouble("clicks-per-second-per-ring", 3.5);

            if (plugin.getSuitManager().isFullyProtected(player)) {
                cps *= cfg.getDouble("suit-multiplier", 0.35);
            } else if (plugin.getRadiationManager().getImmunitySeconds(player) > 0) {
                cps *= cfg.getDouble("immune-multiplier", 0.5);
            }
            cps = Math.min(cps, cfg.getDouble("max-clicks-per-second", 25.0));

            // tasodifiy tebranish
            double noise = cfg.getDouble("noise", 0.25);
            double expected = cps * interval / 20.0 * (1.0 - noise + random.nextDouble() * noise * 2);

            int clicks = poisson(expected);
            if (random.nextDouble() < cfg.getDouble("burst-chance", 0.02) * interval) {
                clicks += 2 + random.nextInt(3);
            }
            for (int i = 0; i < Math.min(clicks, 6); i++) playClick(player, cfg);

            if (showReadout && holding) {
                double dose = cps * cfg.getDouble("dose-per-click", 0.4) * (0.9 + random.nextDouble() * 0.2);
                int ring = plugin.getRadiationManager().getRingAt(loc.getBlockX(), loc.getBlockZ());
                player.sendActionBar(Text.component(plugin.msg("geiger-readout",
                        "{value}", String.format(Locale.US, "%.2f", dose),
                        "{ring}", String.valueOf(ring))));
            }
        }
    }

    private void playClick(Player player, ConfigurationSection cfg) {
        List<String> sounds = cfg.getStringList("sounds");
        if (sounds.isEmpty()) return;
        String key = sounds.get(random.nextInt(sounds.size()));

        double pitchMin = cfg.getDouble("pitch-min", 1.7);
        double pitchMax = Math.max(pitchMin, cfg.getDouble("pitch-max", 2.0));
        float pitch = (float) (pitchMin + random.nextDouble() * (pitchMax - pitchMin));
        float volume = (float) (cfg.getDouble("volume", 0.45) * (0.75 + random.nextDouble() * 0.25));

        player.playSound(player.getLocation(), key, SoundCategory.MASTER, volume, pitch);
    }

    /** Knuth usuli: kutilgan chertishlar soni lambda bo'lganda tasodifiy son */
    private int poisson(double lambda) {
        if (lambda <= 0) return 0;
        double limit = Math.exp(-Math.min(lambda, 20));
        int k = 0;
        double p = 1.0;
        do {
            k++;
            p *= random.nextDouble();
        } while (p > limit && k < 12);
        return k - 1;
    }

    private boolean carries(Player player, String deviceId) {
        for (ItemStack item : player.getInventory().getContents()) {
            if (isDevice(item, deviceId)) return true;
        }
        return false;
    }

    private boolean isDevice(ItemStack item, String deviceId) {
        return item != null && deviceId.equals(plugin.getCustomItemManager().getId(item));
    }
}
