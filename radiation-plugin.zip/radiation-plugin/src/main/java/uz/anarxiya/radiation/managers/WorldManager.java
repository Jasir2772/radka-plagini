package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.World;
import org.bukkit.WorldCreator;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Comparator;
import java.util.List;
import java.util.stream.Stream;

public class WorldManager {

    private final RadiationPlugin plugin;
    private final StructureManager structureManager;
    private BukkitTask countdownTask;

    // reset oralig'ini tick'da hisoblab boradigan soniya sanog'i
    private long secondsUntilReset;

    public WorldManager(RadiationPlugin plugin, StructureManager structureManager) {
        this.plugin = plugin;
        this.structureManager = structureManager;
    }

    public void scheduleAutoReset() {
        long hours = plugin.getConfig().getLong("world.reset-interval-hours", 24);
        secondsUntilReset = hours * 3600L;

        // Har soniyada 1 marta hisoblaydi, ogohlantirish vaqtlarini tekshiradi
        countdownTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            secondsUntilReset--;

            List<Integer> warnMinutes = plugin.getConfig().getIntegerList("world.reset-warning-minutes");
            long minutesLeft = secondsUntilReset / 60;

            if (secondsUntilReset > 0 && secondsUntilReset % 60 == 0 && warnMinutes.contains((int) minutesLeft)) {
                broadcastWarning((int) minutesLeft);
            }

            if (secondsUntilReset <= 0) {
                resetWorld();
                secondsUntilReset = hours * 3600L;
            }
        }, 20L, 20L);
    }

    public void cancelTasks() {
        if (countdownTask != null) countdownTask.cancel();
    }

    private void broadcastWarning(int minutes) {
        Bukkit.broadcastMessage(plugin.msg("reset-broadcast", "{minutes}", String.valueOf(minutes)));
    }

    /** Dunyoni darhol reset qiladi: o'yinchilarni chiqaradi, o'chiradi, o'chiradi (delete), qayta yaratadi, strukturalarni joylashtiradi */
    public void resetWorld() {
        String worldName = plugin.getConfig().getString("world.name", "world1");
        World world = Bukkit.getWorld(worldName);

        if (world != null) {
            // O'yinchilarni spawn dunyosiga chiqarish
            World safeWorld = Bukkit.getWorlds().get(0); // asosiy dunyo (world)
            for (Player p : world.getPlayers()) {
                p.teleport(safeWorld.getSpawnLocation());
                p.sendMessage(plugin.msg("reset-teleport"));
            }

            Bukkit.unloadWorld(world, false);
        }

        // Dunyo papkasini diskdan o'chirish
        File worldFolder = new File(Bukkit.getWorldContainer(), worldName);
        deleteDirectory(worldFolder.toPath());

        // Yangi dunyo yaratish (bir xil nom bilan, generator config'dan olinishi mumkin)
        WorldCreator creator = new WorldCreator(worldName);
        World newWorld = creator.createWorld();

        if (newWorld != null) {
            if (plugin.getConfig().getBoolean("world.border-enabled", true)) {
                int size = plugin.getConfig().getInt("world.size", 10000);
                newWorld.getWorldBorder().setCenter(
                        plugin.getConfig().getInt("world.center-x", 0),
                        plugin.getConfig().getInt("world.center-z", 0));
                newWorld.getWorldBorder().setSize(size);
            }

            // Strukturalarni joylashtirish (chunklar generatsiya bo'lganidan keyin ishlashi kerak,
            // shu sabab bir tick keyinga qoldiramiz)
            Bukkit.getScheduler().runTaskLater(plugin, () -> structureManager.generateAll(newWorld), 40L);
        }

        Bukkit.broadcastMessage(plugin.msg("reset-done"));
    }

    private void deleteDirectory(Path path) {
        if (!Files.exists(path)) return;
        try (Stream<Path> walk = Files.walk(path)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> {
                try {
                    Files.delete(p);
                } catch (IOException ignored) {
                }
            });
        } catch (IOException e) {
            plugin.getLogger().warning("Dunyo papkasini o'chirishda xatolik: " + e.getMessage());
        }
    }

    public long getSecondsUntilReset() {
        return secondsUntilReset;
    }
}
