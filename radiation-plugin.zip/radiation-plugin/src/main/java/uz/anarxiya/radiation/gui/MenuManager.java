package uz.anarxiya.radiation.gui;

import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.Sound;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryAction;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.InventoryHolder;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.Text;

import java.util.*;

/**
 * /radiation menu - sandiq loot'i va mob drop'larini o'yin ichida boshqarish.
 * O'zgarishlar darhol loot.yml / mobs.yml ga saqlanadi.
 */
public class MenuManager implements Listener {

    private enum Kind { LOOT, MOBS }

    private static final int PAGE_SIZE = 45;

    private static class MenuHolder implements InventoryHolder {
        Inventory inventory;
        final Map<Integer, Runnable> actions = new HashMap<>();

        // faqat loot muharriri uchun
        boolean editor;
        Kind kind;
        String path;
        int page;
        Runnable back;

        @Override
        public Inventory getInventory() {
            return inventory;
        }
    }

    private final RadiationPlugin plugin;

    public MenuManager(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    // =====================================================================
    //  Menyular
    // =====================================================================

    public void openMain(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = create(h, 27, "§8☢ Radiatsiya menyusi");

        button(h, inv, 10, icon(Material.CHEST, "§eZona sandiq loot'i",
                "§7Har bir zonadagi umumiy sandiq loot'i"), () -> openZoneSelect(p));
        button(h, inv, 12, icon(Material.BARREL, "§eStruktura loot'i",
                "§7Bunker, laboratoriya, harbiy post...", "§7uchun qo'shimcha loot"), () -> openStructureSelect(p));
        button(h, inv, 14, icon(Material.ZOMBIE_HEAD, "§eMob loot'i",
                "§7Moblar o'lganda tushadigan buyumlar"), () -> openMobRingSelect(p));
        button(h, inv, 16, icon(Material.COMPARATOR, "§aYml fayllarni qayta yuklash",
                "§7Qo'lda yml tahrir qilgan bo'lsangiz bosing"), () -> {
            plugin.reloadAll();
            p.sendMessage("§aBarcha sozlamalar qayta yuklandi.");
        });
        fillEmpty(inv);
        open(p, inv);
    }

    private void openZoneSelect(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = create(h, 27, "§8Zona sandiq loot'i");
        Material[] mats = {Material.LIME_CONCRETE, Material.YELLOW_CONCRETE, Material.ORANGE_CONCRETE, Material.RED_CONCRETE};
        int[] slots = {10, 12, 14, 16};
        for (int r = 1; r <= 4; r++) {
            final int ring = r;
            int count = plugin.getConfigManager().loot().getMapList("zones.ring-" + ring).size();
            button(h, inv, slots[r - 1], icon(mats[r - 1], "§e" + ring + "-zona loot'i", "§7Yozuvlar soni: §f" + count),
                    () -> openEditor(p, Kind.LOOT, "zones.ring-" + ring, ring + "-zona sandiq loot'i", () -> openZoneSelect(p)));
        }
        button(h, inv, 22, icon(Material.BARRIER, "§cOrqaga"), () -> openMain(p));
        fillEmpty(inv);
        open(p, inv);
    }

    private void openStructureSelect(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = create(h, 36, "§8Struktura loot'i");
        ConfigurationSection section = plugin.getConfigManager().loot().getConfigurationSection("structures");
        int slot = 0;
        if (section != null) {
            for (String type : section.getKeys(false)) {
                if (slot >= 27) break;
                int count = section.getMapList(type).size();
                button(h, inv, slot++, icon(structureIcon(type), "§e" + type, "§7Yozuvlar soni: §f" + count),
                        () -> openEditor(p, Kind.LOOT, "structures." + type, "Struktura: " + type, () -> openStructureSelect(p)));
            }
        }
        button(h, inv, 31, icon(Material.BARRIER, "§cOrqaga"), () -> openMain(p));
        fillEmpty(inv);
        open(p, inv);
    }

    private void openMobRingSelect(Player p) {
        MenuHolder h = new MenuHolder();
        Inventory inv = create(h, 27, "§8Mob loot'i - zonani tanlang");
        Material[] mats = {Material.LIME_CONCRETE, Material.YELLOW_CONCRETE, Material.ORANGE_CONCRETE, Material.RED_CONCRETE};
        int[] slots = {10, 12, 14, 16};
        for (int r = 1; r <= 4; r++) {
            final int ring = r;
            int count = plugin.getMobManager().ringMobs(ring).size();
            button(h, inv, slots[r - 1], icon(mats[r - 1], "§e" + ring + "-zona moblari", "§7Moblar soni: §f" + count),
                    () -> openMobList(p, ring, 0));
        }
        button(h, inv, 22, icon(Material.BARRIER, "§cOrqaga"), () -> openMain(p));
        fillEmpty(inv);
        open(p, inv);
    }

    private void openMobList(Player p, int ring, int page) {
        MenuHolder h = new MenuHolder();
        Inventory inv = create(h, 54, "§8" + ring + "-zona moblari");
        List<Map<String, Object>> mobs = plugin.getMobManager().ringMobs(ring);
        int pages = Math.max(1, (mobs.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        int current = Math.max(0, Math.min(page, pages - 1));

        for (int i = 0; i < PAGE_SIZE; i++) {
            int idx = current * PAGE_SIZE + i;
            if (idx >= mobs.size()) break;
            Map<String, Object> data = mobs.get(idx);
            String id = String.valueOf(data.get("id"));
            Material egg = Material.matchMaterial(String.valueOf(data.getOrDefault("fallback-base", "ZOMBIE")) + "_SPAWN_EGG");
            if (egg == null) egg = Material.PAPER;
            int drops = plugin.getConfigManager().mobs().getMapList("ring-" + ring + ".mobs." + id + ".drops").size();
            button(h, inv, i, icon(egg, Text.color(String.valueOf(data.getOrDefault("display-name", id))),
                    "§7id: §f" + id,
                    "§7HP: §f" + data.get("health") + " §7Zarar: §f" + data.get("damage"),
                    "§7Drop yozuvlari: §f" + drops, "", "§aBosing - drop'larni tahrirlash"),
                    () -> openEditor(p, Kind.MOBS, "ring-" + ring + ".mobs." + id + ".drops", "Mob drop: " + id,
                            () -> openMobList(p, ring, current)));
        }
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler());
        if (current > 0) button(h, inv, 45, icon(Material.ARROW, "§eOldingi sahifa"), () -> openMobList(p, ring, current - 1));
        if (current < pages - 1) button(h, inv, 53, icon(Material.ARROW, "§eKeyingi sahifa"), () -> openMobList(p, ring, current + 1));
        button(h, inv, 49, icon(Material.BARRIER, "§cOrqaga"), () -> openMobRingSelect(p));
        open(p, inv);
    }

    // =====================================================================
    //  Loot muharriri
    // =====================================================================

    private void openEditor(Player p, Kind kind, String path, String title, Runnable back) {
        MenuHolder h = new MenuHolder();
        h.editor = true;
        h.kind = kind;
        h.path = path;
        h.back = back;
        Inventory inv = create(h, 54, "§8" + title);
        renderEditor(h);
        open(p, inv);
    }

    private void renderEditor(MenuHolder h) {
        Inventory inv = h.inventory;
        inv.clear();

        List<Map<?, ?>> entries = yaml(h.kind).getMapList(h.path);
        int pages = Math.max(1, (entries.size() + PAGE_SIZE - 1) / PAGE_SIZE);
        h.page = Math.max(0, Math.min(h.page, pages - 1));

        for (int i = 0; i < PAGE_SIZE; i++) {
            int idx = h.page * PAGE_SIZE + i;
            if (idx >= entries.size()) break;
            inv.setItem(i, entryIcon(entries.get(idx)));
        }
        for (int i = PAGE_SIZE; i < 54; i++) inv.setItem(i, filler());

        if (h.page > 0) inv.setItem(45, icon(Material.ARROW, "§eOldingi sahifa"));
        if (h.page < pages - 1) inv.setItem(53, icon(Material.ARROW, "§eKeyingi sahifa"));
        inv.setItem(47, icon(Material.PAPER, "§7Sahifa §f" + (h.page + 1) + "/" + pages, "§7Jami yozuvlar: §f" + entries.size()));
        inv.setItem(48, icon(Material.BARRIER, "§cOrqaga"));
        inv.setItem(49, icon(Material.EMERALD, "§a➕ Buyum qo'shish",
                "§7Inventaringizdan buyumni kursorga oling",
                "§7(bosib ushlang) va shu tugmani bosing.",
                "§7Enchant va nomi ham saqlanadi.",
                "§7Maxsus buyum (antirad va h.k.) ham bo'ladi."));
        inv.setItem(50, icon(Material.BOOK, "§eYo'riqnoma",
                "§aChap tugma§7: ehtimol +5%",
                "§aO'ng tugma§7: ehtimol -5%",
                "§aShift+Chap§7: maksimal miqdor +1",
                "§aShift+O'ng§7: maksimal miqdor -1",
                "§aF (qo'l almashtirish)§7: minimal miqdor +1",
                "§cQ (tashlash)§7: yozuvni o'chirish"));
    }

    private ItemStack entryIcon(Map<?, ?> entry) {
        ItemStack item = plugin.getLootManager().createDisplayItem(entry);
        ItemMeta meta = item.getItemMeta();
        List<String> lore = meta.hasLore() && meta.getLore() != null ? new ArrayList<>(meta.getLore()) : new ArrayList<>();

        int min = (int) num(entry.get("min"), 1);
        int max = (int) num(entry.get("max"), min);
        lore.add("");
        lore.add("§7Ehtimol: §e" + Math.round(num(entry.get("chance"), 0.5) * 100) + "%");
        lore.add("§7Miqdor: §e" + (min == max ? String.valueOf(min) : min + "-" + max));
        lore.add("§8Chap/O'ng: ehtimol | Shift: maks | F: min | Q: o'chirish");
        meta.setLore(lore);
        item.setItemMeta(meta);
        return item;
    }

    private void handleEditorClick(Player p, MenuHolder h, InventoryClickEvent e) {
        int slot = e.getRawSlot();
        if (slot < PAGE_SIZE) {
            editEntry(h, slot, e.getClick());
            return;
        }
        switch (slot) {
            case 45 -> {
                if (h.page > 0) {
                    h.page--;
                    renderEditor(h);
                }
            }
            case 53 -> {
                h.page++;
                renderEditor(h);
            }
            case 48 -> h.back.run();
            case 49 -> addFromCursor(p, h, e.getCursor());
            default -> { }
        }
    }

    private void editEntry(MenuHolder h, int slot, ClickType click) {
        YamlConfiguration yml = yaml(h.kind);
        List<Map<String, Object>> list = mutableList(yml.getMapList(h.path));
        int idx = h.page * PAGE_SIZE + slot;
        if (idx >= list.size()) return;

        Map<String, Object> entry = list.get(idx);
        double chance = num(entry.get("chance"), 0.5);
        int min = (int) num(entry.get("min"), 1);
        int max = (int) num(entry.get("max"), min);

        switch (click) {
            case LEFT -> chance = round2(Math.min(1.0, chance + 0.05));
            case RIGHT -> chance = round2(Math.max(0.0, chance - 0.05));
            case SHIFT_LEFT -> max = Math.min(64, max + 1);
            case SHIFT_RIGHT -> max = Math.max(1, max - 1);
            case SWAP_OFFHAND -> min = min >= max ? 1 : min + 1;
            case DROP, CONTROL_DROP -> list.remove(idx);
            default -> {
                return;
            }
        }
        if (click != ClickType.DROP && click != ClickType.CONTROL_DROP) {
            if (min > max) min = max;
            entry.put("chance", chance);
            entry.put("min", min);
            entry.put("max", max);
        }

        yml.set(h.path, list);
        saveYaml(h.kind);
        renderEditor(h);
    }

    private void addFromCursor(Player p, MenuHolder h, ItemStack cursor) {
        if (cursor == null || cursor.getType().isAir()) {
            p.sendMessage("§eAvval inventaringizdan buyumni kursorga oling (bosib ushlab turing), so'ng §a➕§e tugmasini bosing.");
            return;
        }

        Map<String, Object> entry = new LinkedHashMap<>();
        String customId = plugin.getCustomItemManager().getId(cursor);
        String suitPart = plugin.getSuitManager().getPartName(cursor);

        if (customId != null) {
            entry.put("custom", customId);
        } else if (suitPart != null) {
            entry.put("custom", "suit_" + suitPart);
        } else {
            entry.put("item", cursor.getType().name());
            ItemMeta meta = cursor.getItemMeta();
            if (meta != null) {
                if (meta.hasDisplayName()) entry.put("name", meta.getDisplayName());
                if (meta.hasLore() && meta.getLore() != null) entry.put("lore", new ArrayList<>(meta.getLore()));
            }
            if (!cursor.getEnchantments().isEmpty()) {
                List<String> enchants = new ArrayList<>();
                for (Map.Entry<Enchantment, Integer> en : cursor.getEnchantments().entrySet()) {
                    enchants.add(en.getKey().getKey().getKey() + ":" + en.getValue());
                }
                entry.put("enchants", enchants);
            }
        }
        entry.put("min", 1);
        entry.put("max", Math.max(1, cursor.getAmount()));
        entry.put("chance", plugin.getConfig().getDouble("menu.default-chance", 0.5));

        YamlConfiguration yml = yaml(h.kind);
        List<Map<String, Object>> list = mutableList(yml.getMapList(h.path));
        list.add(entry);
        yml.set(h.path, list);
        saveYaml(h.kind);

        h.page = Integer.MAX_VALUE; // oxirgi sahifaga (renderEditor to'g'rilaydi)
        renderEditor(h);
        p.sendMessage("§aQo'shildi: §f" + (entry.get("custom") != null ? entry.get("custom") : entry.get("item"))
                + " §7(ehtimol " + Math.round(num(entry.get("chance"), 0.5) * 100) + "%, miqdor 1-" + entry.get("max") + ")");
    }

    // =====================================================================
    //  Eventlar
    // =====================================================================

    @EventHandler
    public void onClick(InventoryClickEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder h)) return;
        if (!(e.getWhoClicked() instanceof Player p)) return;

        if (!p.hasPermission("radiation.admin")) {
            e.setCancelled(true);
            p.closeInventory();
            return;
        }
        if (e.getClickedInventory() == null) return;

        if (e.getClickedInventory() != top) {
            // o'z inventaridagi oddiy bosishlarga ruxsat (kursorga buyum olish uchun), menyuga tashlashni bloklaymiz
            if (e.isShiftClick() || e.getAction() == InventoryAction.COLLECT_TO_CURSOR) e.setCancelled(true);
            return;
        }

        e.setCancelled(true);
        if (h.editor) {
            handleEditorClick(p, h, e);
        } else {
            Runnable action = h.actions.get(e.getRawSlot());
            if (action != null) action.run();
        }
        if (!h.actions.isEmpty() || h.editor) p.playSound(p.getLocation(), Sound.UI_BUTTON_CLICK, 0.4f, 1.2f);
    }

    @EventHandler
    public void onDrag(InventoryDragEvent e) {
        Inventory top = e.getView().getTopInventory();
        if (!(top.getHolder() instanceof MenuHolder)) return;
        for (int slot : e.getRawSlots()) {
            if (slot < top.getSize()) {
                e.setCancelled(true);
                return;
            }
        }
    }

    // =====================================================================
    //  Yordamchi metodlar
    // =====================================================================

    private Inventory create(MenuHolder holder, int size, String title) {
        Inventory inv = Bukkit.createInventory(holder, size, Text.component(title));
        holder.inventory = inv;
        return inv;
    }

    /** Menyuni keyingi tickda ochamiz (klik eventi ichida inventar almashtirish xavfsizroq) */
    private void open(Player p, Inventory inv) {
        Bukkit.getScheduler().runTask(plugin, () -> p.openInventory(inv));
    }

    private void button(MenuHolder h, Inventory inv, int slot, ItemStack icon, Runnable action) {
        inv.setItem(slot, icon);
        h.actions.put(slot, action);
    }

    private void fillEmpty(Inventory inv) {
        for (int i = 0; i < inv.getSize(); i++) {
            if (inv.getItem(i) == null) inv.setItem(i, filler());
        }
    }

    private ItemStack filler() {
        return icon(Material.GRAY_STAINED_GLASS_PANE, " ");
    }

    private ItemStack icon(Material material, String name, String... lore) {
        ItemStack item = new ItemStack(material);
        ItemMeta meta = item.getItemMeta();
        meta.setDisplayName(name);
        if (lore.length > 0) meta.setLore(Arrays.asList(lore));
        item.setItemMeta(meta);
        return item;
    }

    private Material structureIcon(String type) {
        return switch (type) {
            case "ruined_house" -> Material.COBBLESTONE;
            case "supply_cache" -> Material.HAY_BLOCK;
            case "bunker" -> Material.IRON_BARS;
            case "lab" -> Material.BREWING_STAND;
            case "military_post" -> Material.SHIELD;
            case "schematic" -> Material.PAPER;
            default -> Material.CHEST;
        };
    }

    private YamlConfiguration yaml(Kind kind) {
        return kind == Kind.LOOT ? plugin.getConfigManager().loot() : plugin.getConfigManager().mobs();
    }

    private void saveYaml(Kind kind) {
        if (kind == Kind.LOOT) plugin.getConfigManager().saveLoot();
        else plugin.getConfigManager().saveMobs();
    }

    private List<Map<String, Object>> mutableList(List<Map<?, ?>> source) {
        List<Map<String, Object>> result = new ArrayList<>();
        for (Map<?, ?> map : source) {
            Map<String, Object> copy = new LinkedHashMap<>();
            for (Map.Entry<?, ?> en : map.entrySet()) copy.put(String.valueOf(en.getKey()), en.getValue());
            result.add(copy);
        }
        return result;
    }

    private double num(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return def;
        }
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
