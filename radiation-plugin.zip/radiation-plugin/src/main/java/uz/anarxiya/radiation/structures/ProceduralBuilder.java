package uz.anarxiya.radiation.structures;

import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.World;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.block.data.BlockData;
import org.bukkit.block.data.Directional;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import static org.bukkit.Material.*;
import static org.bukkit.block.BlockFace.*;

/**
 * Sxematik fayl (.schem) va WorldEdit KERAK BO'LMAGAN, kod orqali quriladigan strukturalar.
 * Turlari: ruined_house, supply_cache, bunker, lab, military_post
 */
public class ProceduralBuilder {

    public static final List<String> TYPES =
            List.of("ruined_house", "supply_cache", "bunker", "lab", "military_post");

    private static final int INVALID = Integer.MIN_VALUE;
    private static final BlockFace[] HORIZONTAL = {NORTH, SOUTH, EAST, WEST};

    /** groundY - yer sathi, anchorX/Z - qo'riqchilar chiqadigan nuqta, containers - sandiq/bochkalar joyi */
    public record Result(int groundY, int anchorX, int anchorZ, List<Location> containers) {}

    private final World world;
    private final Random rnd;
    private final int maxDiff;
    private final List<Location> containers = new ArrayList<>();

    public ProceduralBuilder(World world, Random rnd, int maxHeightDifference) {
        this.world = world;
        this.rnd = rnd;
        this.maxDiff = maxHeightDifference;
    }

    /** Berilgan turdagi strukturani (cx, cz) atrofida quradi. Joy yaroqsiz bo'lsa null qaytaradi. */
    public Result build(String type, int cx, int cz) {
        containers.clear();
        return switch (type) {
            case "ruined_house" -> ruinedHouse(cx, cz);
            case "supply_cache" -> supplyCache(cx, cz);
            case "bunker" -> bunker(cx, cz);
            case "lab" -> lab(cx, cz);
            case "military_post" -> militaryPost(cx, cz);
            default -> null;
        };
    }

    // =====================================================================
    //  1) VAYRON UY  (9x9)
    // =====================================================================
    private Result ruinedHouse(int cx, int cz) {
        int gy = checkSite(cx, cz, 4, 4);
        if (gy == INVALID) return null;
        levelSite(cx, gy, cz, 4, 4, 6);

        Material[] walls = {COBBLESTONE, MOSSY_COBBLESTONE, STONE_BRICKS, MOSSY_STONE_BRICKS, CRACKED_STONE_BRICKS};
        Material[] floor = {SPRUCE_PLANKS, DARK_OAK_PLANKS, COBBLESTONE, MOSSY_COBBLESTONE};

        for (int x = cx - 4; x <= cx + 4; x++) {
            for (int z = cz - 4; z <= cz + 4; z++) {
                int dx = x - cx, dz = z - cz;
                set(x, gy, z, pick(floor));

                // tom (qisman buzilgan)
                if (rnd.nextInt(100) < 45) set(x, gy + 5, z, pick(SPRUCE_PLANKS, DARK_OAK_PLANKS));

                boolean edge = Math.abs(dx) == 4 || Math.abs(dz) == 4;
                if (!edge) continue;

                for (int y = 1; y <= 4; y++) {
                    boolean door = dz == -4 && dx == 0 && y <= 2;
                    boolean window = y == 3 && ((Math.abs(dz) == 4 && Math.abs(dx) == 2)
                            || (Math.abs(dx) == 4 && Math.abs(dz) == 2));
                    if (door || window) continue;
                    if (rnd.nextInt(100) < 8 + y * 7) continue; // yuqori qismlar ko'proq buzilgan
                    set(x, gy + y, z, pick(walls));
                }
            }
        }

        chest(cx - 3, gy + 1, cz + 3, EAST);
        set(cx + 3, gy + 1, cz + 3, CRAFTING_TABLE);
        set(cx + 3, gy + 1, cz - 3, CAULDRON);
        if (rnd.nextInt(100) < 50) chest(cx + 3, gy + 1, cz, WEST);

        for (int i = 0; i < 5; i++) {
            set(cx + rnd.nextInt(7) - 3, gy + 2 + rnd.nextInt(3), cz + rnd.nextInt(7) - 3, COBWEB);
        }
        return new Result(gy, cx, cz, new ArrayList<>(containers));
    }

    // =====================================================================
    //  2) TA'MINOT SANDIG'I  (7x7)
    // =====================================================================
    private Result supplyCache(int cx, int cz) {
        int gy = checkSite(cx, cz, 3, 3);
        if (gy == INVALID) return null;
        levelSite(cx, gy, cz, 3, 3, 4);

        Material[] ground = {COARSE_DIRT, GRAVEL, COBBLESTONE, MOSSY_COBBLESTONE};
        for (int x = cx - 3; x <= cx + 3; x++) {
            for (int z = cz - 3; z <= cz + 3; z++) {
                set(x, gy, z, pick(ground));
                int dx = Math.abs(x - cx), dz = Math.abs(z - cz);
                boolean corner = dx == 3 && dz == 3;
                boolean edge = dx == 3 || dz == 3;
                if (corner) {
                    set(x, gy + 1, z, COBBLESTONE_WALL);
                    if (rnd.nextInt(100) < 70) set(x, gy + 2, z, COBBLESTONE_WALL);
                } else if (edge && rnd.nextInt(100) < 60) {
                    set(x, gy + 1, z, HAY_BLOCK);
                }
            }
        }

        chest(cx, gy + 1, cz, HORIZONTAL[rnd.nextInt(4)]);
        barrel(cx + 1, gy + 1, cz + 1);
        barrel(cx - 1, gy + 1, cz - 1);
        set(cx + 1, gy + 2, cz + 1, LANTERN);
        return new Result(gy, cx, cz, new ArrayList<>(containers));
    }

    // =====================================================================
    //  3) YER OSTI BUNKERI  (kirish quduq orqali, ichida xona)
    // =====================================================================
    private Result bunker(int cx, int cz) {
        int hx = cx, hz = cz + 4; // kirish (lyuk) nuqtasi
        int gy = checkSite(hx, hz, 2, 2);
        if (gy == INVALID) return null;

        int fy = gy - 9; // xona pol sathi
        if (fy - 2 < world.getMinHeight() + 2) return null;

        levelSite(hx, gy, hz, 2, 2, 3);

        // Yer usti maydoncha
        for (int x = hx - 2; x <= hx + 2; x++) {
            for (int z = hz - 2; z <= hz + 2; z++) {
                set(x, gy, z, pick(STONE_BRICKS, CRACKED_STONE_BRICKS, COBBLESTONE, POLISHED_ANDESITE));
            }
        }
        // Quduq atrofidagi past devor (shimol tomondan kirish ochiq)
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (dx == 0 && dz == -1) continue;
                set(hx + dx, gy + 1, hz + dz, COBBLESTONE_WALL);
            }
        }

        // Xona: qattiq blok, ichi bo'sh
        fill(cx - 5, fy - 1, cz - 5, cx + 5, fy + 4, cz + 5, STONE_BRICKS);
        fill(cx - 4, fy, cz - 4, cx + 4, fy + 3, cz + 4, AIR);
        for (int x = cx - 4; x <= cx + 4; x++) {
            for (int z = cz - 4; z <= cz + 4; z++) {
                if (rnd.nextInt(3) == 0) set(x, fy - 1, z, pick(POLISHED_ANDESITE, CRACKED_STONE_BRICKS, MOSSY_STONE_BRICKS));
            }
        }

        // Quduq (shaft): shiftdan yer betigacha
        for (int y = fy + 4; y <= gy - 1; y++) {
            set(hx, y, hz, AIR);
            set(hx - 1, y, hz, STONE_BRICKS);
            set(hx + 1, y, hz, STONE_BRICKS);
            set(hx, y, hz - 1, STONE_BRICKS);
            set(hx, y, hz + 1, STONE_BRICKS);
        }
        // Narvon (orqasidagi blok janubda -> narvon shimolga qaraydi)
        for (int y = fy; y <= gy; y++) {
            setFacing(hx, y, hz, LADDER, NORTH);
        }

        // Ichki jihozlar
        for (int sx : new int[]{-3, 3}) {
            for (int sz : new int[]{-3, 3}) {
                set(cx + sx, fy + 3, cz + sz, SEA_LANTERN);
            }
        }
        chest(cx - 4, fy, cz - 2, EAST);
        chest(cx + 4, fy, cz - 3, WEST);
        barrel(cx + 4, fy, cz - 1);
        barrel(cx + 4, fy, cz);
        setFacing(cx, fy, cz - 4, FURNACE, SOUTH);
        set(cx + 1, fy, cz - 4, CRAFTING_TABLE);
        fill(cx - 4, fy, cz + 1, cx - 4, fy + 1, cz + 3, BOOKSHELF);

        return new Result(gy, hx, hz, new ArrayList<>(containers));
    }

    // =====================================================================
    //  4) LABORATORIYA  (13x11)
    // =====================================================================
    private Result lab(int cx, int cz) {
        int gy = checkSite(cx, cz, 6, 5);
        if (gy == INVALID) return null;
        levelSite(cx, gy, cz, 6, 5, 7);

        Material[] wall = {LIGHT_GRAY_CONCRETE, WHITE_CONCRETE, LIGHT_GRAY_CONCRETE, GRAY_CONCRETE};
        Material[] floor = {LIGHT_GRAY_CONCRETE, GRAY_CONCRETE, POLISHED_ANDESITE};

        for (int x = cx - 6; x <= cx + 6; x++) {
            for (int z = cz - 5; z <= cz + 5; z++) {
                int dx = x - cx, dz = z - cz;
                set(x, gy, z, pick(floor));

                // tom (75% yopiq)
                if (rnd.nextInt(100) >= 25) set(x, gy + 5, z, LIGHT_GRAY_CONCRETE);

                boolean edge = Math.abs(dx) == 6 || Math.abs(dz) == 5;
                if (!edge) continue;

                boolean corner = Math.abs(dx) == 6 && Math.abs(dz) == 5;
                for (int y = 1; y <= 4; y++) {
                    boolean door = dz == -5 && (dx == 0 || dx == 1) && y <= 2;
                    if (door) continue;
                    if (rnd.nextInt(100) < 6) continue; // buzilgan joylar

                    boolean window = !corner && (y == 2 || y == 3)
                            && ((Math.abs(dz) == 5 && dx % 3 == 0) || (Math.abs(dx) == 6 && dz % 3 == 0));
                    if (window) {
                        if (rnd.nextInt(100) >= 35) set(x, gy + y, z, LIME_STAINED_GLASS);
                    } else {
                        set(x, gy + y, z, pick(wall));
                    }
                }
            }
        }

        // Jihozlar
        set(cx - 5, gy + 1, cz - 2, BREWING_STAND);
        set(cx - 5, gy + 1, cz, CAULDRON);
        set(cx - 5, gy + 1, cz + 2, BREWING_STAND);
        fill(cx - 1, gy + 1, cz + 1, cx, gy + 3, cz + 2, LIME_STAINED_GLASS); // reaktor sig'imi
        set(cx - 3, gy + 4, cz, SEA_LANTERN);
        set(cx + 3, gy + 4, cz, SEA_LANTERN);
        set(cx, gy + 4, cz - 3, SEA_LANTERN);
        chest(cx + 5, gy + 1, cz - 2, WEST);
        chest(cx + 5, gy + 1, cz + 2, WEST);

        // Eshik oldida "radioaktiv dog'lar"
        for (int i = 0; i < 16; i++) {
            int x = cx + rnd.nextInt(7) - 3;
            int z = cz - 6 - rnd.nextInt(4);
            int y = surfaceY(x, z);
            if (block(x, y, z).isLiquid()) continue;
            set(x, y, z, LIME_CONCRETE);
        }
        return new Result(gy, cx, cz, new ArrayList<>(containers));
    }

    // =====================================================================
    //  5) HARBIY POST + KUZATUV MINORASI  (15x15)
    // =====================================================================
    private Result militaryPost(int cx, int cz) {
        int gy = checkSite(cx, cz, 7, 7);
        if (gy == INVALID) return null;
        levelSite(cx, gy, cz, 7, 7, 9);

        Material[] ground = {GRAVEL, COARSE_DIRT, COBBLESTONE, STONE};
        for (int x = cx - 7; x <= cx + 7; x++) {
            for (int z = cz - 7; z <= cz + 7; z++) {
                set(x, gy, z, pick(ground));

                int dx = x - cx, dz = z - cz;
                boolean edge = Math.abs(dx) == 7 || Math.abs(dz) == 7;
                boolean gate = dz == 7 && Math.abs(dx) <= 1;
                if (!edge || gate) continue;
                if (rnd.nextInt(100) < 25) continue; // devordagi bo'shliqlar

                set(x, gy + 1, z, COBBLESTONE_WALL);
                if (rnd.nextInt(100) < 60) set(x, gy + 2, z, COBBLESTONE_WALL);
            }
        }

        // Kuzatuv minorasi
        for (int sx : new int[]{-1, 1}) {
            for (int sz : new int[]{-1, 1}) {
                for (int y = 1; y <= 5; y++) set(cx + sx, gy + y, cz + sz, SPRUCE_LOG);
            }
        }
        fill(cx - 1, gy + 6, cz - 1, cx + 1, gy + 6, cz + 1, SPRUCE_PLANKS);
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                if (dx == 0 && dz == 0) continue;
                if (dx == -1 && dz == 1) continue; // narvondan chiqish joyi
                set(cx + dx, gy + 7, cz + dz, SPRUCE_FENCE);
            }
        }
        for (int y = gy + 1; y <= gy + 6; y++) {
            setFacing(cx - 1, y, cz + 2, LADDER, SOUTH);
        }
        chest(cx, gy + 7, cz, SOUTH);

        // Chodir
        int tx = cx - 4, tz = cz - 3;
        for (int dx = -2; dx <= 2; dx++) {
            for (int dz = -2; dz <= 2; dz++) set(tx + dx, gy + 3, tz + dz, GREEN_WOOL);
            for (int y = 1; y <= 2; y++) set(tx + dx, gy + y, tz - 2, GREEN_WOOL);
        }
        for (int sx : new int[]{-2, 2}) {
            for (int sz : new int[]{-2, 2}) {
                set(tx + sx, gy + 1, tz + sz, OAK_FENCE);
                set(tx + sx, gy + 2, tz + sz, OAK_FENCE);
            }
        }
        chest(tx, gy + 1, tz - 1, SOUTH);
        barrel(tx + 1, gy + 1, tz);

        // Ta'minot yashiklari darvoza yonida
        barrel(cx + 4, gy + 1, cz + 4);
        barrel(cx + 5, gy + 1, cz + 4);
        chest(cx + 5, gy + 1, cz + 5, NORTH);

        return new Result(gy, cx, cz, new ArrayList<>(containers));
    }

    // =====================================================================
    //  Yordamchi metodlar
    // =====================================================================

    /** Joy yaroqliligini tekshiradi (suv yo'qmi, tekismi). Yer sathini (Y) qaytaradi yoki INVALID. */
    private int checkSite(int cx, int cz, int hx, int hz) {
        int[][] points = {{0, 0}, {-hx, -hz}, {hx, -hz}, {-hx, hz}, {hx, hz}};
        int min = Integer.MAX_VALUE, max = Integer.MIN_VALUE;
        for (int[] p : points) {
            int x = cx + p[0], z = cz + p[1];
            int y = surfaceY(x, z);
            if (block(x, y, z).isLiquid()) return INVALID;
            min = Math.min(min, y);
            max = Math.max(max, y);
        }
        if (max - min > maxDiff) return INVALID;
        return surfaceY(cx, cz);
    }

    /** Maydonni tekislaydi: ustidagi daraxt/tepalikni olib tashlaydi, pastdagi bo'shliqni to'ldiradi */
    private void levelSite(int cx, int gy, int cz, int hx, int hz, int height) {
        int worldTop = world.getMaxHeight() - 2;
        for (int x = cx - hx; x <= cx + hx; x++) {
            for (int z = cz - hz; z <= cz + hz; z++) {
                int top = surfaceY(x, z);

                // pastki bo'shliqni to'ldirish
                for (int y = Math.max(top + 1, gy - 10); y < gy; y++) {
                    set(x, y, z, DIRT);
                }
                // asos qattiq bo'lsin
                if (!block(x, gy - 1, z).getType().isSolid()) set(x, gy - 1, z, DIRT);

                // yuqoridagi to'siqlarni tozalash
                int clearTo = Math.min(worldTop, Math.max(top, gy + height) + 4);
                for (int y = gy; y <= clearTo; y++) {
                    if (block(x, y, z).getType() != AIR) set(x, y, z, AIR);
                }
            }
        }
    }

    private int surfaceY(int x, int z) {
        return world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
    }

    private Block block(int x, int y, int z) {
        return world.getBlockAt(x, y, z);
    }

    private void set(int x, int y, int z, Material material) {
        if (y < world.getMinHeight() || y >= world.getMaxHeight()) return;
        block(x, y, z).setType(material, false);
    }

    private void setFacing(int x, int y, int z, Material material, BlockFace face) {
        if (y < world.getMinHeight() || y >= world.getMaxHeight()) return;
        Block b = block(x, y, z);
        b.setType(material, false);
        BlockData data = b.getBlockData();
        if (data instanceof Directional directional) {
            try {
                directional.setFacing(face);
                b.setBlockData(directional, false);
            } catch (IllegalArgumentException ignored) {
                // bu blok shu yo'nalishni qabul qilmaydi
            }
        }
    }

    private void fill(int x1, int y1, int z1, int x2, int y2, int z2, Material material) {
        for (int x = Math.min(x1, x2); x <= Math.max(x1, x2); x++) {
            for (int y = Math.min(y1, y2); y <= Math.max(y1, y2); y++) {
                for (int z = Math.min(z1, z2); z <= Math.max(z1, z2); z++) {
                    set(x, y, z, material);
                }
            }
        }
    }

    private void chest(int x, int y, int z, BlockFace facing) {
        setFacing(x, y, z, CHEST, facing);
        containers.add(block(x, y, z).getLocation());
    }

    private void barrel(int x, int y, int z) {
        setFacing(x, y, z, BARREL, UP);
        containers.add(block(x, y, z).getLocation());
    }

    private Material pick(Material... options) {
        return options[rnd.nextInt(options.length)];
    }
}
