package uz.anarxiya.radiation.listeners;

import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.LivingEntity;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import uz.anarxiya.radiation.RadiationPlugin;

import java.util.List;
import java.util.Map;

/** Bizning moblar o'lganda mobs.yml dagi "drops" va "exp" bo'yicha loot tushiradi (vanilla fallback ham, MythicMobs ham) */
public class MobDeathListener implements Listener {

    private final RadiationPlugin plugin;

    public MobDeathListener(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onDeath(EntityDeathEvent event) {
        if (!plugin.getConfig().getBoolean("mob-drops.enabled", true)) return;

        LivingEntity entity = event.getEntity();
        String id = plugin.getMobManager().getRadiationMobId(entity);
        if (id == null) return;

        if (plugin.getMobManager().isMythicSpawned(entity)
                && !plugin.getConfig().getBoolean("mob-drops.apply-to-mythic", true)) {
            return;
        }
        if (plugin.getConfig().getBoolean("mob-drops.only-player-kills", false) && entity.getKiller() == null) {
            return;
        }

        ConfigurationSection section = plugin.getMobManager().findMobSection(id);
        if (section == null) return;

        if (plugin.getConfig().getBoolean("mob-drops.replace-vanilla", false)) {
            event.getDrops().clear();
        }

        List<Map<?, ?>> entries = section.getMapList("drops");
        for (ItemStack drop : plugin.getLootManager().rollDrops(entries)) {
            event.getDrops().add(drop);
        }
        if (section.contains("exp")) {
            event.setDroppedExp(Math.max(0, section.getInt("exp")));
        }
    }
}
