package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.Location;
import org.bukkit.attribute.Attribute;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;

import java.util.*;

public class MobManager {

    private final RadiationPlugin plugin;
    private BukkitTask task;
    private final Random random = new Random();
    private boolean mythicMobsAvailable;

    public MobManager(RadiationPlugin plugin) {
        this.plugin = plugin;
        this.mythicMobsAvailable = Bukkit.getPluginManager().isPluginEnabled("MythicMobs");
    }

    public void start() {
        // Har 5 soniyada har bir o'yinchi atrofida spawn tekshiruvi
        task = Bukkit.getScheduler().runTaskTimer(plugin, this::trySpawnAroundPlayers, 100L, 100L);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void trySpawnAroundPlayers() {
        String worldName = plugin.getConfig().getString("world.name", "world1");
        var world = Bukkit.getWorld(worldName);
        if (world == null) return;

        for (Player player : world.getPlayers()) {
            int ring = plugin.getRadiationManager().getRingAt(
                    player.getLocation().getBlockX(), player.getLocation().getBlockZ());
            int cappedRing = Math.min(ring, 4);

            ConfigurationSection ringSection = plugin.getConfig()
                    .getConfigurationSection("mobs.ring-" + cappedRing);
            if (ringSection == null) continue;

            double chance = ringSection.getDouble("spawn-chance", 0.15);
            if (random.nextDouble() > chance) continue;

            List<Map<?, ?>> mobList = ringSection.getMapList("list");
            if (mobList.isEmpty()) continue;

            Map<?, ?> mobData = mobList.get(random.nextInt(mobList.size()));
            spawnMob(player.getLocation(), mobData);
        }
    }

    private void spawnMob(Location near, Map<?, ?> data) {
        Location spawnLoc = randomNearbyLocation(near, 15, 30);
        if (spawnLoc == null) return;

        String mythicId = String.valueOf(data.get("model"));
        String displayName = String.valueOf(data.getOrDefault("display-name", "Radiatsiya Mahluqi"));
        double health = toDouble(data.get("health"), 20.0);
        double damage = toDouble(data.get("damage"), 4.0);

        if (mythicMobsAvailable && mythicId != null && !mythicId.equals("null")) {
            boolean spawned = trySpawnMythicMob(mythicId, spawnLoc);
            if (spawned) return;
        }

        // Fallback: vanilla mob + custom stats
        String baseName = String.valueOf(data.getOrDefault("fallback-base", "ZOMBIE"));
        EntityType type;
        try {
            type = EntityType.valueOf(baseName);
        } catch (IllegalArgumentException e) {
            type = EntityType.ZOMBIE;
        }

        LivingEntity entity = (LivingEntity) spawnLoc.getWorld().spawnEntity(spawnLoc, type);
        entity.setCustomName(displayName.replace("&", "§"));
        entity.setCustomNameVisible(true);

        var maxHealthAttr = entity.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealthAttr != null) {
            maxHealthAttr.setBaseValue(health);
            entity.setHealth(health);
        }
        var dmgAttr = entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (dmgAttr != null) {
            dmgAttr.setBaseValue(damage);
        }

        entity.setRemoveWhenFarAway(true);
    }

    /** MythicMobs API orqali mob chaqirishga urinadi. API mavjud bo'lmasa false qaytaradi. */
    private boolean trySpawnMythicMob(String mobId, Location loc) {
        try {
            // MythicMobs 5.x API: io.lumine.mythic.bukkit.MythicBukkit
            Class<?> mythicBukkitClass = Class.forName("io.lumine.mythic.bukkit.MythicBukkit");
            Object mythicInstance = mythicBukkitClass.getMethod("inst").invoke(null);
            Object mobManager = mythicBukkitClass.getMethod("getMobManager").invoke(mythicInstance);

            Class<?> optionalClass = Class.forName("java.util.Optional");
            Object mobTypeOpt = mobManager.getClass()
                    .getMethod("getMobType", String.class)
                    .invoke(mobManager, mobId);
            boolean present = (boolean) optionalClass.getMethod("isPresent").invoke(mobTypeOpt);
            if (!present) return false;

            Object mobType = optionalClass.getMethod("get").invoke(mobTypeOpt);
            // spawnMob(MythicMob type, Location loc, double level)
            mobManager.getClass()
                    .getMethod("spawnMob", mobType.getClass().getInterfaces().length > 0
                            ? mobType.getClass().getInterfaces()[0] : mobType.getClass(), Location.class, double.class)
                    .invoke(mobManager, mobType, loc, 1.0);
            return true;
        } catch (Throwable t) {
            // MythicMobs topilmadi yoki mob ID config qilinmagan -> fallback ishlatiladi
            return false;
        }
    }

    private Location randomNearbyLocation(Location center, int minDist, int maxDist) {
        double angle = random.nextDouble() * Math.PI * 2;
        int dist = minDist + random.nextInt(maxDist - minDist + 1);
        double x = center.getX() + Math.cos(angle) * dist;
        double z = center.getZ() + Math.sin(angle) * dist;
        var world = center.getWorld();
        int y = world.getHighestBlockYAt((int) x, (int) z) + 1;
        return new Location(world, x, y, z);
    }

    private double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return def;
        }
    }
}
