package uz.anarxiya.radiation.managers;

import org.bukkit.Bukkit;
import org.bukkit.GameMode;
import org.bukkit.HeightMap;
import org.bukkit.Location;
import org.bukkit.NamespacedKey;
import org.bukkit.World;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.command.CommandSender;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.persistence.PersistentDataType;
import org.bukkit.plugin.Plugin;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.hooks.MythicHook;
import uz.anarxiya.radiation.util.Text;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.util.*;

public class MobManager {

    public enum InstallResult { INSTALLED, ALREADY_EXISTS, NO_MYTHICMOBS, ERROR }

    private static final String MYTHIC_RESOURCE = "mythicmobs/RadiationZone.yml";
    private static final String MYTHIC_FILE = "RadiationZone.yml";

    private final RadiationPlugin plugin;
    private final Random random = new Random();
    private final NamespacedKey mobKey;
    private final NamespacedKey guardKey;
    private final NamespacedKey mobIdKey;
    private final NamespacedKey mythicKey;
    private final Set<String> warnedMissing = new HashSet<>();
    private final Map<String, Long> guardCooldown = new HashMap<>();
    private MythicHook mythicHook; // MythicMobs ulanmagan bo'lsa null
    private BukkitTask task;

    public MobManager(RadiationPlugin plugin) {
        this.plugin = plugin;
        this.mobKey = new NamespacedKey(plugin, "radiation_mob");
        this.guardKey = new NamespacedKey(plugin, "radiation_guard");
        this.mobIdKey = new NamespacedKey(plugin, "radiation_mob_id");
        this.mythicKey = new NamespacedKey(plugin, "radiation_mythic");
        initMythic();
    }

    // =====================================================================
    //  MythicMobs ulanishi
    // =====================================================================

    private void initMythic() {
        if (!plugin.getConfig().getBoolean("mythicmobs.use-mythic", true)) {
            plugin.getLogger().info("MythicMobs o'chirilgan (config: mythicmobs.use-mythic=false) - vanilla moblar ishlatiladi.");
            return;
        }
        if (!Bukkit.getPluginManager().isPluginEnabled("MythicMobs")) {
            plugin.getLogger().info("MythicMobs topilmadi - vanilla fallback moblar ishlatiladi.");
            return;
        }
        try {
            mythicHook = new MythicHook();
            plugin.getLogger().info("MythicMobs API ga muvaffaqiyatli ulandi.");
        } catch (Throwable t) {
            mythicHook = null;
            plugin.getLogger().warning("MythicMobs topildi, lekin API ga ulab bo'lmadi: " + t);
        }
    }

    public boolean isMythicConnected() {
        return mythicHook != null;
    }

    /** RadiationZone.yml ni plugins/MythicMobs/Mobs/ ichiga ko'chiradi */
    public InstallResult installMythicConfigs(boolean overwrite) {
        Plugin mythic = Bukkit.getPluginManager().getPlugin("MythicMobs");
        if (mythic == null) return InstallResult.NO_MYTHICMOBS;

        File mobsDir = new File(mythic.getDataFolder(), "Mobs");
        if (!mobsDir.exists() && !mobsDir.mkdirs()) {
            plugin.getLogger().warning("MythicMobs/Mobs papkasini yaratib bo'lmadi.");
            return InstallResult.ERROR;
        }

        File target = new File(mobsDir, MYTHIC_FILE);
        if (target.exists() && !overwrite) return InstallResult.ALREADY_EXISTS;

        try (InputStream in = plugin.getResource(MYTHIC_RESOURCE)) {
            if (in == null) {
                plugin.getLogger().warning("Plagin ichida " + MYTHIC_RESOURCE + " topilmadi.");
                return InstallResult.ERROR;
            }
            Files.copy(in, target.toPath(), StandardCopyOption.REPLACE_EXISTING);
        } catch (IOException e) {
            plugin.getLogger().warning("MythicMobs faylini ko'chirib bo'lmadi: " + e.getMessage());
            return InstallResult.ERROR;
        }

        plugin.getLogger().info("MythicMobs moblari o'rnatildi: " + target.getPath());
        if (plugin.getConfig().getBoolean("mythicmobs.reload-after-install", true)) {
            Bukkit.getScheduler().runTaskLater(plugin,
                    () -> Bukkit.dispatchCommand(Bukkit.getConsoleSender(), "mm reload"), 20L);
        }
        return InstallResult.INSTALLED;
    }

    /** config'dagi har bir mob MythicMobs'da bormi - tekshirib, natijani yuboradi */
    public void sendMythicStatus(CommandSender sender) {
        if (mythicHook == null) {
            sender.sendMessage("§cMythicMobs ulanmagan. Sabab: plagin o'rnatilmagan, o'chirilgan yoki config'da use-mythic=false.");
            sender.sendMessage("§7Hozir barcha moblar vanilla fallback bo'lib chiqadi.");
            return;
        }

        int found = 0;
        List<String> missing = new ArrayList<>();
        for (Map<String, Object> data : allMobData()) {
            String model = str(data.get("model"), null);
            if (model == null || model.isBlank()) continue;
            if (mythicHook.hasMob(model)) found++;
            else missing.add(model);
        }

        sender.sendMessage("§aMythicMobs ulangan. Topilgan moblar: §f" + found + "§a, topilmagan: §f" + missing.size());
        if (!missing.isEmpty()) {
            List<String> shown = missing.subList(0, Math.min(10, missing.size()));
            sender.sendMessage("§eTopilmaganlar: §7" + String.join(", ", shown) + (missing.size() > 10 ? " ..." : ""));
            sender.sendMessage("§eYechim: §f/radiation mythic install §7(so'ng MythicMobs reload qilinadi)");
        }
    }

    // =====================================================================
    //  Doimiy tasklar
    // =====================================================================

    public void start() {
        // Har 5 soniyada: atrofdagi spawn tekshiruvi + struktura qo'riqchilari
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            try {
                trySpawnAroundPlayers();
                tickGuards();
            } catch (Throwable t) {
                plugin.getLogger().warning("MobManager xatolik: " + t);
            }
        }, 100L, 100L);
    }

    public void stop() {
        if (task != null) task.cancel();
    }

    private void trySpawnAroundPlayers() {
        World world = getRadiationWorld();
        if (world == null) return;

        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == GameMode.SPECTATOR) continue;

            int ring = Math.min(plugin.getRadiationManager().getRingAt(
                    player.getLocation().getBlockX(), player.getLocation().getBlockZ()), 4);

            ConfigurationSection ringSection = plugin.getConfigManager().mobs().getConfigurationSection("ring-" + ring);
            if (ringSection == null) continue;

            double chance = ringSection.getDouble("spawn-chance", 0.15);
            if (random.nextDouble() > chance) continue;

            List<Map<String, Object>> mobList = ringMobs(ring);
            if (mobList.isEmpty()) continue;

            Location spawnLoc = randomNearbyLocation(player.getLocation(), 15, 30);
            if (spawnLoc == null) continue;

            // Bir chunkda cheksiz mob to'planib qolmasligi uchun
            if (countMobsInChunk(spawnLoc) >= ringSection.getInt("max-per-chunk", 3)) continue;

            spawnEntry(spawnLoc, mobList.get(random.nextInt(mobList.size())), false);
        }
    }

    /** O'yinchi strukturaga yaqinlashganda, u yerda qo'riqchi moblar chiqadi */
    private void tickGuards() {
        if (!plugin.getConfig().getBoolean("structures.guards.enabled", true)) return;
        World world = getRadiationWorld();
        if (world == null) return;

        List<StructureManager.PlacedStructure> placed = plugin.getStructureManager().getPlaced();
        if (placed.isEmpty()) return;

        double radius = plugin.getConfig().getDouble("structures.guards.activation-radius", 40.0);
        long cooldownMs = plugin.getConfig().getLong("structures.guards.respawn-cooldown-seconds", 300L) * 1000L;
        long now = System.currentTimeMillis();

        for (Player player : world.getPlayers()) {
            if (player.getGameMode() == GameMode.SPECTATOR) continue;
            Location pl = player.getLocation();

            for (StructureManager.PlacedStructure s : placed) {
                double dx = pl.getX() - s.x();
                double dz = pl.getZ() - s.z();
                if (dx * dx + dz * dz > radius * radius) continue;

                int want = plugin.getStructureManager().getGuardCount(s.type());
                if (want <= 0) continue;
                if (guardCooldown.getOrDefault(s.key(), 0L) > now) continue;
                if (!world.isChunkLoaded(s.x() >> 4, s.z() >> 4)) continue;

                Location center = new Location(world, s.x() + 0.5, s.y() + 1, s.z() + 0.5);
                int alive = 0;
                for (Entity e : world.getNearbyEntities(center, 24, 24, 24)) {
                    if (e.getPersistentDataContainer().has(guardKey, PersistentDataType.BYTE)) alive++;
                }
                if (alive >= want) continue;

                int ring = Math.min(plugin.getRadiationManager().getRingAt(s.x(), s.z()), 4);
                List<Map<String, Object>> mobList = ringMobs(ring);
                if (mobList.isEmpty()) continue;

                for (int i = alive; i < want; i++) {
                    Location loc = findGuardLocation(center);
                    if (loc == null) continue;
                    spawnEntry(loc, mobList.get(random.nextInt(mobList.size())), true);
                }
                guardCooldown.put(s.key(), now + cooldownMs);
            }
        }
    }

    // =====================================================================
    //  Mob chaqirish
    // =====================================================================

    /** id bo'yicha mob ma'lumotini topadi (mobs.yml). "id" kaliti qo'shib beriladi. */
    public Map<String, Object> findMobData(String id) {
        for (Map<String, Object> data : allMobData()) {
            if (id.equalsIgnoreCase(str(data.get("id"), ""))) return data;
        }
        return null;
    }

    /** id bo'yicha mobning mobs.yml dagi bo'limi (drops, exp o'qish uchun) */
    public ConfigurationSection findMobSection(String id) {
        var mobs = plugin.getConfigManager().mobs();
        for (String ringKey : mobs.getKeys(false)) {
            ConfigurationSection ring = mobs.getConfigurationSection(ringKey);
            if (ring == null) continue;
            ConfigurationSection list = ring.getConfigurationSection("mobs");
            if (list == null) continue;
            for (String key : list.getKeys(false)) {
                if (key.equalsIgnoreCase(id)) return list.getConfigurationSection(key);
            }
        }
        return null;
    }

    public List<String> allMobIds() {
        List<String> ids = new ArrayList<>();
        for (Map<String, Object> data : allMobData()) ids.add(str(data.get("id"), "?"));
        return ids;
    }

    /** Berilgan ringdagi barcha mob ma'lumotlari */
    public List<Map<String, Object>> ringMobs(int ring) {
        List<Map<String, Object>> result = new ArrayList<>();
        ConfigurationSection ringSection = plugin.getConfigManager().mobs().getConfigurationSection("ring-" + ring);
        if (ringSection == null) return result;
        ConfigurationSection list = ringSection.getConfigurationSection("mobs");
        if (list == null) return result;
        for (String id : list.getKeys(false)) {
            ConfigurationSection s = list.getConfigurationSection(id);
            if (s == null) continue;
            Map<String, Object> data = new LinkedHashMap<>(s.getValues(false));
            data.put("id", id);
            result.add(data);
        }
        return result;
    }

    private List<Map<String, Object>> allMobData() {
        List<Map<String, Object>> all = new ArrayList<>();
        for (String key : plugin.getConfigManager().mobs().getKeys(false)) {
            if (!key.startsWith("ring-")) continue;
            try {
                all.addAll(ringMobs(Integer.parseInt(key.substring(5))));
            } catch (NumberFormatException ignored) {
            }
        }
        return all;
    }

    /** Entity bizning moblarimizdan bo'lsa, uning id'sini qaytaradi (aks holda null) */
    public String getRadiationMobId(Entity entity) {
        return entity.getPersistentDataContainer().get(mobIdKey, PersistentDataType.STRING);
    }

    public boolean isMythicSpawned(Entity entity) {
        return entity.getPersistentDataContainer().has(mythicKey, PersistentDataType.BYTE);
    }

    /**
     * Mobni chaqiradi: avval MythicMobs (model), bo'lmasa vanilla fallback.
     * @param guard true bo'lsa - struktura qo'riqchisi (chunk limitiga kirmaydi, doimiy)
     */
    public LivingEntity spawnEntry(Location loc, Map<String, Object> data, boolean guard) {
        LivingEntity spawned = null;
        boolean viaMythic = false;

        String model = str(data.get("model"), null);
        if (mythicHook != null && model != null && !model.isBlank() && !model.equalsIgnoreCase("null")) {
            try {
                double level = plugin.getConfig().getDouble("mythicmobs.level", 1.0);
                Entity entity = mythicHook.spawn(model, loc, level);
                if (entity instanceof LivingEntity living) {
                    spawned = living;
                    viaMythic = true;
                } else if (entity == null && warnedMissing.add(model)) {
                    plugin.getLogger().warning("MythicMobs'da '" + model + "' topilmadi - vanilla fallback ishlatiladi. "
                            + "Yechim: /radiation mythic install");
                }
            } catch (Throwable t) {
                if (warnedMissing.add("error:" + model)) {
                    plugin.getLogger().warning("MythicMobs '" + model + "' chaqirishda xatolik: " + t);
                }
            }
        }

        if (spawned == null) spawned = spawnVanilla(loc, data);
        if (spawned == null) return null;

        var pdc = spawned.getPersistentDataContainer();
        pdc.set(guard ? guardKey : mobKey, PersistentDataType.BYTE, (byte) 1);
        pdc.set(mobIdKey, PersistentDataType.STRING, str(data.get("id"), "unknown"));
        if (viaMythic) pdc.set(mythicKey, PersistentDataType.BYTE, (byte) 1);
        if (guard) {
            spawned.setPersistent(true);
            spawned.setRemoveWhenFarAway(false);
        }
        return spawned;
    }

    private LivingEntity spawnVanilla(Location loc, Map<String, Object> data) {
        String displayName = str(data.get("display-name"), "§2Radiatsiya Mahluqi");
        double health = toDouble(data.get("health"), 20.0);
        double damage = toDouble(data.get("damage"), 4.0);

        EntityType type;
        try {
            type = EntityType.valueOf(str(data.get("fallback-base"), "ZOMBIE").toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException e) {
            type = EntityType.ZOMBIE;
        }
        Class<? extends Entity> entityClass = type.getEntityClass();
        if (entityClass == null || !LivingEntity.class.isAssignableFrom(entityClass)) {
            type = EntityType.ZOMBIE;
        }

        Entity raw = loc.getWorld().spawnEntity(loc, type);
        if (!(raw instanceof LivingEntity entity)) {
            raw.remove();
            return null;
        }

        entity.setCustomName(Text.color(displayName));
        entity.setCustomNameVisible(true);

        AttributeInstance maxHealth = entity.getAttribute(Attribute.GENERIC_MAX_HEALTH);
        if (maxHealth != null) {
            maxHealth.setBaseValue(health);
            entity.setHealth(Math.min(health, maxHealth.getValue()));
        }
        AttributeInstance attack = entity.getAttribute(Attribute.GENERIC_ATTACK_DAMAGE);
        if (attack != null) attack.setBaseValue(damage);

        // Quyoshda yonib ketmasligi uchun
        entity.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, false, false));
        entity.setRemoveWhenFarAway(true);
        return entity;
    }

    // =====================================================================
    //  Joy tanlash / hisoblash
    // =====================================================================

    private int countMobsInChunk(Location loc) {
        World world = loc.getWorld();
        int cx = loc.getBlockX() >> 4, cz = loc.getBlockZ() >> 4;
        if (!world.isChunkLoaded(cx, cz)) return Integer.MAX_VALUE;

        int count = 0;
        for (Entity e : world.getChunkAt(cx, cz).getEntities()) {
            if (e.getPersistentDataContainer().has(mobKey, PersistentDataType.BYTE)) count++;
        }
        return count;
    }

    private Location randomNearbyLocation(Location center, int minDist, int maxDist) {
        World world = center.getWorld();
        double angle = random.nextDouble() * Math.PI * 2;
        int dist = minDist + random.nextInt(maxDist - minDist + 1);
        int x = (int) Math.floor(center.getX() + Math.cos(angle) * dist);
        int z = (int) Math.floor(center.getZ() + Math.sin(angle) * dist);

        if (!world.isChunkLoaded(x >> 4, z >> 4)) return null; // yangi chunk yuklamaymiz
        if (!world.getWorldBorder().isInside(new Location(world, x, 64, z))) return null;

        int y = world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
        if (world.getBlockAt(x, y, z).isLiquid()) return null;
        return new Location(world, x + 0.5, y + 1, z + 0.5);
    }

    /** Struktura atrofida (3-9 blok) qo'riqchi uchun yer betida joy topadi */
    private Location findGuardLocation(Location center) {
        World world = center.getWorld();
        for (int i = 0; i < 8; i++) {
            double angle = random.nextDouble() * Math.PI * 2;
            int dist = 3 + random.nextInt(7);
            int x = (int) Math.floor(center.getX() + Math.cos(angle) * dist);
            int z = (int) Math.floor(center.getZ() + Math.sin(angle) * dist);
            if (!world.isChunkLoaded(x >> 4, z >> 4)) continue;

            int y = world.getHighestBlockYAt(x, z, HeightMap.MOTION_BLOCKING_NO_LEAVES);
            if (world.getBlockAt(x, y, z).isLiquid()) continue;
            if (Math.abs(y + 1 - center.getBlockY()) > 3) continue; // tom yoki tepalikka chiqib qolmasin
            return new Location(world, x + 0.5, y + 1, z + 0.5);
        }
        return null;
    }

    private World getRadiationWorld() {
        return Bukkit.getWorld(plugin.getConfig().getString("world.name", "world1"));
    }

    private String str(Object o, String def) {
        return o != null ? String.valueOf(o) : def;
    }

    private double toDouble(Object o, double def) {
        if (o instanceof Number n) return n.doubleValue();
        try {
            return Double.parseDouble(String.valueOf(o));
        } catch (Exception e) {
            return def;
        }
    }
}
