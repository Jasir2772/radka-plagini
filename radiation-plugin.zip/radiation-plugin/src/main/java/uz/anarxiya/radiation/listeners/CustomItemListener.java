package uz.anarxiya.radiation.listeners;

import org.bukkit.Sound;
import org.bukkit.attribute.Attribute;
import org.bukkit.attribute.AttributeInstance;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.inventory.EquipmentSlot;
import org.bukkit.inventory.ItemStack;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.EffectUtil;

import java.util.Locale;

/** Maxsus buyumlarni (antirad tabletka, tibbiy to'plam...) o'ng tugma bilan ishlatish */
public class CustomItemListener implements Listener {

    private final RadiationPlugin plugin;

    public CustomItemListener(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onUse(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;

        ItemStack item = event.getItem();
        String id = plugin.getCustomItemManager().getId(item);
        if (id == null) return;

        ConfigurationSection section = plugin.getCustomItemManager().getSection(id);
        if (section == null) return;

        Player player = event.getPlayer();
        String action = section.getString("action", "").toUpperCase(Locale.ROOT);
        boolean used = false;

        switch (action) {
            case "IMMUNITY" -> {
                int seconds = section.getInt("seconds", 120);
                plugin.getRadiationManager().grantImmunity(player, seconds);
                long total = plugin.getRadiationManager().getImmunitySeconds(player);
                player.sendMessage(plugin.msg("immunity-gained", "{seconds}", String.valueOf(total)));
                used = true;
            }
            case "HEAL" -> {
                double amount = section.getDouble("amount", 10.0);
                AttributeInstance maxHealth = player.getAttribute(Attribute.GENERIC_MAX_HEALTH);
                double max = maxHealth != null ? maxHealth.getValue() : 20.0;
                player.setHealth(Math.min(max, player.getHealth() + amount));
                player.sendMessage(plugin.msg("item-used-heal"));
                used = true;
            }
            case "CLEAR_EFFECTS" -> {
                EffectUtil.clearNegative(player);
                used = true;
            }
            default -> { }
        }

        if (!used) return;

        if (section.getBoolean("clear-effects", false)) {
            EffectUtil.clearNegative(player);
        }

        event.setCancelled(true);
        consumeOne(player);
        player.playSound(player.getLocation(), Sound.ENTITY_GENERIC_DRINK, 1f, 1f);
    }

    private void consumeOne(Player player) {
        ItemStack hand = player.getInventory().getItemInMainHand();
        if (hand.getAmount() <= 1) {
            player.getInventory().setItemInMainHand(null);
        } else {
            hand.setAmount(hand.getAmount() - 1);
        }
    }
}
