package uz.anarxiya.radiation.managers;

import net.kyori.adventure.bossbar.BossBar;
import org.bukkit.Bukkit;
import org.bukkit.Color;
import org.bukkit.GameRule;
import org.bukkit.Location;
import org.bukkit.Particle;
import org.bukkit.SoundCategory;
import org.bukkit.WeatherType;
import org.bukkit.World;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;
import uz.anarxiya.radiation.RadiationPlugin;
import uz.anarxiya.radiation.util.EffectUtil;
import uz.anarxiya.radiation.util.Text;

import java.util.*;

/**
 * Radiatsiyali dunyo atmosferasi (faqat serverdan, resurs paketsiz):
 *  - osmon: har ring uchun shom/tun vaqti + yomg'ir (faqat o'yinchi ekranida, per-player)
 *  - tushayotgan kul va yashil radioaktiv chang zarrachalari
 *  - tasodifiy sirli ovozlar
 *  - qorong'u tuman (DARKNESS effekti) tanlangan ringlarda
 *  - ring ko'rsatkichi (bossbar)
 */
public class AtmosphereManager {

    private static final BossBar.Color[] RING_COLORS = {
            BossBar.Color.GREEN, BossBar.Color.YELLOW, BossBar.Color.RED, BossBar.Color.PURPLE};

    private final RadiationPlugin plugin;
    private final Random random = new Random();
    private final Map<UUID, Long> lastSky = new HashMap<>();
    private final Map<UUID, BossBar> bars = new HashMap<>();
    private final Map<UUID, Long> nextSound = new HashMap<>();
    private final Set<String> warned = new HashSet<>();
    private BukkitTask task;

    public AtmosphereManager(RadiationPlugin plugin) {
        this.plugin = plugin;
    }

    public void start() {
        long interval = Math.max(2L, plugin.getConfig().getLong("atmosphere.tick-interval", 10L));
        task = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            try {
                tick();
            } catch (Throwable t) {
                if (warned.add("tick:" + t)) plugin.getLogger().warning("Atmosfera xatosi: " + t);
            }
        }, 60L, interval);
    }

    public void stop() {
        if (task != null) task.cancel();
        for (UUID id : new HashSet<>(union())) release(id);
    }

    private void tick() {
        FileConfiguration cfg = plugin.getConfig();
        World world = Bukkit.getWorld(cfg.getString("world.name", "world1"));
        if (!cfg.getBoolean("atmosphere.enabled", true) || world == null) {
            for (UUID id : new HashSet<>(union())) release(id);
            return;
        }

        if (cfg.getBoolean("atmosphere.sky.world-thunder", false)) applyWorldStorm(world);

        long now = System.currentTimeMillis();
        Set<UUID> present = new HashSet<>();

        for (Player player : world.getPlayers()) {
            present.add(player.getUniqueId());

            Location loc = player.getLocation();
            double ringSize = Math.max(1, cfg.getInt("radiation.ring-size", 2500));
            double dx = loc.getX() - cfg.getInt("world.center-x", 0);
            double dz = loc.getZ() - cfg.getInt("world.center-z", 0);
            double level = Math.sqrt(dx * dx + dz * dz) / ringSize;
            int ring = Math.max(1, Math.min(4, (int) Math.floor(level) + 1));

            applySky(player, ring, now);
            updateBossBar(player, ring, level, (int) (level * ringSize));
            spawnParticles(player, ring);
            ambientSound(player, now);
            applyDarkness(player, ring);
        }

        // dunyodan chiqqan / o'yindan chiqqan o'yinchilarni tozalaymiz
        for (UUID id : new HashSet<>(union())) {
            if (!present.contains(id)) release(id);
        }
    }

    // ---------- Osmon / ob-havo ----------

    private void applySky(Player player, int ring, long now) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("atmosphere.sky.enabled", true)) return;

        Long last = lastSky.get(player.getUniqueId());
        if (last != null && now - last < 5000) return;
        lastSky.put(player.getUniqueId(), now);

        long time = cfg.getLong("atmosphere.sky.time." + ring, 12500L);
        player.setPlayerTime(time, false); // qat'iy vaqt (client tomonda)

        String weather = cfg.getString("atmosphere.sky.weather", "DOWNFALL").toUpperCase(Locale.ROOT);
        switch (weather) {
            case "DOWNFALL" -> player.setPlayerWeather(WeatherType.DOWNFALL);
            case "CLEAR" -> player.setPlayerWeather(WeatherType.CLEAR);
            default -> player.resetPlayerWeather();
        }
    }

    private void applyWorldStorm(World world) {
        world.setGameRule(GameRule.DO_WEATHER_CYCLE, false);
        if (!world.hasStorm()) world.setStorm(true);
        if (!world.isThundering()) world.setThundering(true);
    }

    // ---------- Bossbar ----------

    private void updateBossBar(Player player, int ring, double level, int distance) {
        if (!plugin.getConfig().getBoolean("atmosphere.bossbar.enabled", true)) {
            BossBar old = bars.remove(player.getUniqueId());
            if (old != null) player.hideBossBar(old);
            return;
        }
        float progress = (float) Math.max(0.0, Math.min(1.0, level - Math.floor(level)));
        var title = Text.component(plugin.msg("bossbar-title",
                "{ring}", String.valueOf(ring), "{distance}", String.valueOf(distance)));

        BossBar bar = bars.get(player.getUniqueId());
        if (bar == null) {
            bar = BossBar.bossBar(title, progress, RING_COLORS[ring - 1], BossBar.Overlay.NOTCHED_10);
            bars.put(player.getUniqueId(), bar);
            player.showBossBar(bar);
        } else {
            bar.name(title).progress(progress).color(RING_COLORS[ring - 1]);
        }
    }

    // ---------- Zarrachalar ----------

    private void spawnParticles(Player player, int ring) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("atmosphere.particles.enabled", true)) return;

        int count = cfg.getInt("atmosphere.particles.count-base", 6)
                + cfg.getInt("atmosphere.particles.count-per-ring", 4) * ring;
        double radius = cfg.getDouble("atmosphere.particles.radius", 14.0);

        Location above = player.getLocation().add(0, 4, 0);
        for (String name : cfg.getStringList("atmosphere.particles.types")) {
            Particle particle = findParticle(name);
            if (particle != null) player.spawnParticle(particle, above, count, radius, 4, radius, 0);
        }

        if (cfg.getBoolean("atmosphere.particles.green-dust", true)) {
            Particle dust = findParticle("REDSTONE", "DUST"); // versiyaga qarab nomi farq qiladi
            if (dust != null) {
                int dustCount = cfg.getInt("atmosphere.particles.dust-count", 3) * ring;
                player.spawnParticle(dust, player.getLocation().add(0, 1.5, 0), dustCount,
                        radius / 2, 2, radius / 2, 0, new Particle.DustOptions(Color.fromRGB(90, 255, 60), 1.3f));
            }
        }
    }

    private Particle findParticle(String... names) {
        for (String name : names) {
            try {
                return Particle.valueOf(name.trim().toUpperCase(Locale.ROOT));
            } catch (IllegalArgumentException ignored) {
            }
        }
        if (warned.add("particle:" + names[0])) {
            plugin.getLogger().warning("Noma'lum zarracha turi (atmosphere.particles): " + names[0]);
        }
        return null;
    }

    // ---------- Ovozlar ----------

    private void ambientSound(Player player, long now) {
        FileConfiguration cfg = plugin.getConfig();
        if (!cfg.getBoolean("atmosphere.ambient-sounds.enabled", true)) return;

        List<String> sounds = cfg.getStringList("atmosphere.ambient-sounds.sounds");
        if (sounds.isEmpty()) return;

        int min = Math.max(1, cfg.getInt("atmosphere.ambient-sounds.min-seconds", 20));
        int max = Math.max(min, cfg.getInt("atmosphere.ambient-sounds.max-seconds", 60));

        Long due = nextSound.get(player.getUniqueId());
        if (due == null) {
            nextSound.put(player.getUniqueId(), now + (min + random.nextInt(max - min + 1)) * 1000L);
            return;
        }
        if (now < due) return;

        Location at = player.getLocation().add((random.nextDouble() - 0.5) * 24, 0, (random.nextDouble() - 0.5) * 24);
        float volume = (float) cfg.getDouble("atmosphere.ambient-sounds.volume", 0.5);
        float pitch = 0.7f + random.nextFloat() * 0.4f;
        player.playSound(at, sounds.get(random.nextInt(sounds.size())), SoundCategory.AMBIENT, volume, pitch);

        nextSound.put(player.getUniqueId(), now + (min + random.nextInt(max - min + 1)) * 1000L);
    }

    // ---------- Qorong'u tuman ----------

    private void applyDarkness(Player player, int ring) {
        if (!plugin.getConfig().getIntegerList("atmosphere.darkness.rings").contains(ring)) return;
        PotionEffectType darkness = EffectUtil.resolve("DARKNESS");
        if (darkness != null) {
            player.addPotionEffect(new PotionEffect(darkness, 80, 0, false, false, false));
        }
    }

    // ---------- Tozalash ----------

    private Set<UUID> union() {
        Set<UUID> all = new HashSet<>(lastSky.keySet());
        all.addAll(bars.keySet());
        all.addAll(nextSound.keySet());
        return all;
    }

    private void release(UUID id) {
        Player player = Bukkit.getPlayer(id);
        BossBar bar = bars.remove(id);
        if (player != null) {
            if (bar != null) player.hideBossBar(bar);
            if (lastSky.containsKey(id)) {
                player.resetPlayerTime();
                player.resetPlayerWeather();
            }
        }
        lastSky.remove(id);
        nextSound.remove(id);
    }
}
