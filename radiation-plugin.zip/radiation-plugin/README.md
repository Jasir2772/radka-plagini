# RadiationZone Plugin — O'rnatish qo'llanmasi

## Nima qildi bu plagin?
- `world1` dunyosi har 24 soatda (config'da o'zgartirsa bo'ladi) o'zi avtomatik o'chib, qaytadan yaratiladi
- Markazdan har 2500 blokda radiatsiya kuchayadi (4 ta halqa: 0-2500, 2500-5000, 5000-7500, 7500-10000)
- **Faqat maxsus radiatsiya kostyumi** himoya qiladi — oddiy iron/diamond bronya HECH NARSA bermaydi
- Kostyumsiz kirgan o'yinchiga vaqt o'tishi bilan zarar, nausea/weakness/slow effektlari beriladi va oxir-oqibat o'ladi
- Dunyoga kirganda (teleport, respawn, world o'zgarganda) ekranga ogohlantirish Title chiqadi
- Har bir halqada turli radiatsiyalangan moblar spawn bo'ladi (30-35+ tagacha o'zingiz qo'shishingiz mumkin)
- Strukturalar (binolar) avtomatik joylashtiriladi, ichidagi sandiqlar loot bilan to'ladi, har resetda yangilanadi

---

## 1-QADAM: Kerakli pluginlar (majburiy emas, lekin tavsiya etiladi)

Bu plagin quyidagilar bilan ishlashga moslashtirilgan, lekin ular bo'lmasa ham asosiy funksiyalar (radiatsiya, zarar, dunyo reset) ishlayveradi:

| Plugin | Nima uchun kerak | Bo'lmasa nima bo'ladi |
|---|---|---|
| **WorldEdit** yoki **FastAsyncWorldEdit** | Binolarni avtomatik joylashtirish uchun | Strukturalar joylashtirilmaydi, faqat radiatsiya/moblar ishlaydi |
| **MythicMobs** | 30-35 ta maxsus 3D model/skinli moblar uchun | O'zgartirilgan vanilla moblar (custom nom + kuch) ishlatiladi |

**MythicMobs + resurs paket qanday ishlaydi:**
1. MythicMobs pluginini o'rnating
2. `plugins/MythicMobs/Mobs/` papkasida har bir mob uchun config yozing (masalan `MutantZombie`, `IrradiatedHusk` va h.k. — bizning `config.yml`dagi `model:` nomlariga mos bo'lishi kerak)
3. Maxsus 3D model/skin uchun resurs paket kerak — buni **Blockbench** dasturi orqali o'zingiz yoki freelancer/tayyor resurs paket orqali tayyorlaysiz, keyin MythicMobs/ModelEngine konfiguratsiyasiga ulaysiz
4. Resurs paketni serveringizga ulang (server.properties'dagi `resource-pack` maydoni)

Agar hozircha 3D model tayyor bo'lmasa — hech narsa qilish shart emas, plagin avtomatik ravishda fallback qilib, o'zgartirilgan vanilla moblarni ishlatadi (kuchli, nomi maxsus, lekin standart skin bilan).

## 2-QADAM: Kompilyatsiya qilish

### A) Kompyuterda
```bash
cd radiation-plugin
mvn clean package
```
Natijada `target/RadiationZone.jar` fayli hosil bo'ladi — shuni serveringizning `plugins/` papkasiga tashlang.

### B) Telefonda — GitHub Actions orqali (mvn o'rnatish shart emas)
Loyihada tayyor `.github/workflows/build.yml` bor — GitHub bu faylni ko'rib, har safar kod yuklanganda avtomatik `mvn package` ishlatib, tayyor `.jar` faylni sizga tayyorlab beradi.

**Qadamlar (telefondan, GitHub ilovasi yoki brauzer orqali):**
1. github.com'da yangi **repository** yarating (masalan `radiation-plugin`)
2. Ushbu arxivdagi hamma fayl va papkalarni (`.github` papkasi ham, u yashirin nom bilan boshlanadi — ko'rinmasa "show hidden files" yoqing) o'sha repoga yuklang:
   - GitHub ilovasida repo ochib, "Add file" → "Upload files" orqali, YOKI
   - Fayllarni avval biror fayl menejeriga (masalan "Files by Google") zipdan chiqarib, keyin GitHub mobil saytidan (github.com, "Desktop site" rejimida) yuklash qulayroq
3. Yuklab bo'lgach, repo ichida **Actions** bo'limiga o'ting
4. "Build RadiationZone Plugin" workflow avtomatik ishga tushadi (agar tushmasa, "Run workflow" tugmasini bosing)
5. Build tugagach (yashil ✓ belgisi chiqadi), o'sha run'ni oching, pastda **Artifacts** bo'limidan `RadiationZone-jar` faylni yuklab oling — ichida tayyor `.jar` bor
6. Shu `.jar` faylni serveringizning `plugins/` papkasiga joylang

**Eslatma:** Internetga ulanish kerak (Maven repo'lardan Paper API, WorldEdit va MythicMobs kutubxonalarini yuklab olish uchun) — GitHub Actions'da bu avtomatik, siz hech narsa o'rnatishingiz shart emas.

## 3-QADAM: Birinchi ishga tushirish

1. Serverni ishga tushiring, plagin `plugins/RadiationZone/config.yml` faylini yaratadi
2. `world1` nomli dunyo allaqachon mavjud bo'lsa, config'dagi `world.name` shu nomga mos ekanini tekshiring
3. `plugins/RadiationZone/schematics/` papkasini yarating, unga `.schem` fayllaringizni joylang (WorldEdit bilan `//schem save <nom>` orqali o'zingiz qurgan binolarni saqlashingiz mumkin)
4. Config'dagi `structures.list` ro'yxatiga shu fayl nomlarini yozing

## 4-QADAM: 30-35 ta mobni to'ldirish

`mobs.yml` dagi `ring-1` ... `ring-4` bo'limlariga xohlagancha yangi mob qo'shing (`mobs:` ichiga, id — yangi nom):

```yaml
    yangi_mob_nomi:
      model: "MythicMobsdagiNomi"      # MythicMobs bo'lmasa shunchaki bo'sh qoldiring
      fallback-base: ZOMBIE             # vanilla mob turi (ZOMBIE, SKELETON, SPIDER va h.k.)
      display-name: "§cYangi Mob Nomi"
      health: 50
      damage: 7
      exp: 8
      drops:
        - {item: IRON_INGOT, min: 1, max: 2, chance: 0.5}
```

Shu formatda davom ettirsangiz, 30-35 taga osongina yetkazasiz.

## Komandalar
- `/radiation menu` — loot va mob drop'larini o'yin ichida boshqarish menyusi
- `/radiation reload` — barcha yml fayllarni qayta yuklash
- `/radiation reset` — world1'ni darhol qo'lda reset qilish
- `/radiation info` — keyingi avtomatik resetgacha qolgan vaqt
- `/radiation givesuit <player>` — radiatsiya kostyumini berish
- `/radiation giveitem <id> [player] [soni]` — maxsus buyum (`antirad_pill`, `rad_away`, `medkit`, `suit_helmet`...)
- `/radiation structures generate` — qo'shimcha strukturalarni hozir joylashtirish; `structures list` — ro'yxat
- `/radiation spawnmob <id>` — sinov uchun mob chaqirish (MythicMobs ishlayaptimi tekshirish uchun)
- `/radiation fillchest [struktura_turi]` — qarab turgan sandiqni loot bilan to'ldirish (loot sinovi)
- `/radiation mythic status` — config'dagi 30 mobdan nechtasi MythicMobs'da topilganini ko'rsatadi
- `/radiation mythic install` — mob faylini `plugins/MythicMobs/Mobs/RadiationZone.yml` ga qayta o'rnatadi

## Muhim eslatma (chegaralar)
- Men (AI) haqiqiy 3D model/skin fayllarini (Blockbench formatida) yarata olmayman — bu alohida grafik dizayn ishi. Plagin MythicMobs/resurs paket bilan ishlashga tayyor, lekin modellarni siz yoki dizayner tayyorlashi kerak.
- Endi 5 xil struktura plaginning o'zida bor (kod bilan quriladi). Faqat o'zingizning maxsus binolaringiz kerak bo'lsa, WorldEdit bilan qurib `//schem save` qiling.


---

## v1.1 da nimalar yangi

**MythicMobs (to'g'ridan-to'g'ri API)**
- Plagin MythicMobs bor bo'lsa, birinchi ishga tushishda `RadiationZone.yml` (30 ta mob) ni `plugins/MythicMobs/Mobs/` ga o'zi ko'chiradi va `mm reload` qiladi.
- Tekshirish: `/radiation mythic status`, keyin `/radiation spawnmob mutant_zombie`.
- MythicMobs yo'q bo'lsa yoki mob topilmasa — avvalgidek vanilla fallback ishlaydi.
- Endi moblar soni cheklangan (`max-per-chunk` haqiqatan ishlaydi).

**Strukturalar (WorldEdit shart emas)**
- `ruined_house`, `supply_cache`, `bunker` (yer osti), `lab`, `military_post` (minora bilan). Har biri o'z zonalarida (`rings`) va ehtimolida (`weight`) paydo bo'ladi.
- Asta-sekin quriladi (server qotmaydi), suv/qiya joylar o'tkazib yuboriladi.
- Yaqinlashganda qo'riqchi moblar chiqadi (`structures.guards`).
- Ro'yxat `structures.yml` da saqlanadi (restartdan keyin ham qoladi).

**Loot**
- Sandiq loot'i = zona jadvali + struktura turi jadvali. Sandiq va bochkalar ishlaydi.
- Enchant, nom, lore qo'llab-quvvatlanadi. Maxsus buyumlar: Antirad tabletka, Rad-Away, Tibbiy to'plam (o'ng tugma), laboratoriya/harbiy postda kostyum qismlari (kam ehtimol).

**Eski config'dan o'tish:** birinchi ishga tushishda eski `config.yml` avtomatik `config-old-....yml` ga ko'chiriladi va yangisi yaratiladi. Sozlamalaringizni kerak bo'lsa yangisiga qayta ko'chiring.

**Diqqat:** `world.size: 10000` — bu diametr (markazdan 5000 blok). Shuning uchun 3- va 4-zona deyarli chiqmaydi. To'liq 4 zona kerak bo'lsa `size: 20000` qiling.


---

## v1.2 da nimalar yangi

**Fayllar (hammasi yml orqali boshqariladi)**
| Fayl | Nima |
|---|---|
| `config.yml` | dunyo, radiatsiya, kostyum, MythicMobs, strukturalar, ovozlar, mob drop qoidalari |
| `loot.yml` | sandiq loot'i (zonalar va struktura turlari bo'yicha) |
| `mobs.yml` | 30 ta mob: HP, zarar, exp va **drops** |
| `items.yml` | maxsus buyumlar (antirad, medkit, Geiger schyotchik...) |
| `messages.yml` | barcha o'yinchiga ko'rinadigan xabarlar va titlelar |

**Menyu: `/radiation menu`** (ruxsat: `radiation.admin`)
- Zona loot'i, struktura loot'i, mob loot'i — hammasi menyuda.
- Chap/O'ng tugma: ehtimol ±5%. Shift+Chap/O'ng: maksimal miqdor ±1. F: minimal miqdor +1. Q: o'chirish.
- Yangi buyum qo'shish: inventaringizdagi buyumni kursorga oling va ➕ tugmasini bosing (enchant, nom, maxsus buyumlar saqlanadi).
- O'zgarishlar darhol yml faylga yoziladi. Diqqat: menyu saqlaganda faylning izohlari (#) yo'qolishi mumkin.

**Mob loot'i**
- Moblar o'lganda `mobs.yml` dagi `drops` tushadi (vanilla fallback ham, MythicMobs ham). MythicMobs faylida endi `Drops` yo'q — hammasi bir joyda.
- `config.yml` → `mob-drops`: vanilla drop'ni o'chirish (`replace-vanilla`), faqat o'yinchi o'ldirganda tushirish (`only-player-kills`).

**Geiger schyotchigi ovozi**
- Radiatsiya zonasida chertishlar eshitiladi: markazdan uzoqlashgan sari tezlashadi, tasodifiy (Puasson) va ba'zan ketma-ket "burst" bilan — haqiqiy schyotchikdagidek. Kostyum kiyilsa kamayadi.
- `config.yml` → `sounds.geiger`: `mode: ALWAYS` (doim) yoki `ITEM` (faqat `geiger_counter` buyumi bo'lsa). Qo'lda ushlansa actionbar'da mSv/soat ko'rsatkichi chiqadi.
- Maxsus ovoz (resurs paket) ishlatish uchun `sounds:` ro'yxatiga `"radiation:geiger"` kabi nom yozing.
- Buyum: `/radiation giveitem geiger_counter` (laboratoriya va harbiy postda ham topiladi).
